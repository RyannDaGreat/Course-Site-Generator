package _App_._GUI_._Modes_._CourseDetails_._Actions_;
import _App_.App;
public class Actions
{
    public App app;
    public Actions(App app)
    {
        this.app=app;
    }
}
