package _App_._GUI_._Modes_._CourseDetails_._Transactions_;
import _App_.App;
public class Transactions
{
    public App app;
    public Transactions(App app)
    {
        this.app=app;
    }
    public void initialize()//Required by Ryan's Framework. This is called AFTER everything in the tree has been constructed.
    {

    }
}
