package _App_._GUI_._Modes_._ModeSelector_._Transactions_;
import _App_.App;
public class Transactions
{
    public App app;
    public Transactions(App app)
    {
        this.app=app;
    }
}
