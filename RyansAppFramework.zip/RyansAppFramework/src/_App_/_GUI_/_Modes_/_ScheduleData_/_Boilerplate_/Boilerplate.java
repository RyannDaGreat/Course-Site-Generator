package _App_._GUI_._Modes_._ScheduleData_._Boilerplate_;
import _App_.App;
public class Boilerplate
{
    public App app;
    public Boilerplate(App app)
    {
        this.app=app;
    }
}
