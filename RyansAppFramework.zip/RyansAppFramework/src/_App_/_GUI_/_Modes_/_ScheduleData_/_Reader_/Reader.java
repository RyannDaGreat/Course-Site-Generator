package _App_._GUI_._Modes_._ScheduleData_._Reader_;
import _App_.App;
public class Reader
{
    public App app;
    public Reader(App app)
    {
        this.app=app;
    }
}
