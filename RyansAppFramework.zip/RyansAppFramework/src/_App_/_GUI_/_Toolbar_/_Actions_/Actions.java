package _App_._GUI_._Toolbar_._Actions_;//Created by Ryan on 4/10/17.
import _App_.App;
public class Actions
{
    public App app;
    public Actions(App app)
    {
        this.app=app;
    }
}
