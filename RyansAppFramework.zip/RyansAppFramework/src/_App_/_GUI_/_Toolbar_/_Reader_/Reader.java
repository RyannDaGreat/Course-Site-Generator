package _App_._GUI_._Toolbar_._Reader_;//Created by Ryan on 4/10/17.
import _App_.App;
public class Reader
{
    public App app;
    public Reader(App app)
    {
        this.app=app;
    }
}
