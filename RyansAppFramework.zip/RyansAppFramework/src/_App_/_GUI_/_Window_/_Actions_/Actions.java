package _App_._GUI_._Window_._Actions_;//Created by Ryan on 4/10/17.
import _App_.App;
public class Actions
{
    public App app;
    public Actions(App app)
    {
        this.app=app;
    }
    public void initialize()//Required by Ryan's Framework. This is called AFTER everything in the tree has been constructed.
    {

    }
}
