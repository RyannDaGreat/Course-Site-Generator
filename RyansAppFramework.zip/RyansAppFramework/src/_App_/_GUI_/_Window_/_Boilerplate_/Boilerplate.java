package _App_._GUI_._Window_._Boilerplate_;//Created by Ryan on 4/10/17.
import _App_.App;
import _App_._GUI_._Window_._Actions_.Actions;
public class Boilerplate
{
    public App app;
    public Boilerplate(App app)
    {
        this.app=app;
    }
}
