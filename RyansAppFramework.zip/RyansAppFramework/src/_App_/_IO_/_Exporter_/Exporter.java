package _App_._IO_._Exporter_;//Created by Ryan on 4/10/17.
import _App_.App;
@SuppressWarnings("WeakerAccess")
public class Exporter
{
    public App app;
    public Exporter(App app)
    {
        this.app=app;
    }
}
