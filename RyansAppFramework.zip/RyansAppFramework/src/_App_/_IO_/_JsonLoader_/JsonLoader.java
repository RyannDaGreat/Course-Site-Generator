package _App_._IO_._JsonLoader_;//Created by Ryan on 4/10/17.
import _App_.App;
@SuppressWarnings("WeakerAccess")
public class JsonLoader
{
    public App app;
    public JsonLoader(App app)
    {
        this.app=app;
    }
}
