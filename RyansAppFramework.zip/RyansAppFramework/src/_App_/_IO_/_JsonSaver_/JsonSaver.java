package _App_._IO_._JsonSaver_;//Created by Ryan on 4/10/17.
import _App_.App;
@SuppressWarnings("WeakerAccess")
public class JsonSaver
{
    public App app;
    public JsonSaver(App app)
    {
        this.app=app;
    }
}
