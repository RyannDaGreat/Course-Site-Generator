package _App_._IO_._Misc_;//Created by Ryan on 4/10/17.
import _App_.App;
@SuppressWarnings("WeakerAccess")
public class Misc
{
    public App app;
    public Misc(App app)
    {
        this.app=app;
    }
}
