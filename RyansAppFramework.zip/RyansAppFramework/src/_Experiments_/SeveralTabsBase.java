package _Experiments_;

import javafx.scene.shape.*;
import javafx.scene.paint.*;
import javafx.scene.image.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import javafx.scene.effect.*;
import javafx.scene.control.*;
import java.lang.*;
import javafx.scene.layout.*;

import static _Experiments_.Stylizer.*;
public class SeveralTabsBase extends VBox {

    protected final AnchorPane anchorPane;
    protected final GridPane gridPane;
    protected final ColumnConstraints columnConstraints;
    protected final ColumnConstraints columnConstraints0;
    protected final ColumnConstraints columnConstraints1;
    protected final ColumnConstraints columnConstraints2;
    protected final ColumnConstraints columnConstraints3;
    protected final ColumnConstraints columnConstraints4;
    protected final ColumnConstraints columnConstraints5;
    protected final ColumnConstraints columnConstraints6;
    protected final ColumnConstraints columnConstraints7;
    protected final RowConstraints rowConstraints;
    protected final Button button;
    protected final ImageView imageView;
    protected final Button button0;
    protected final ImageView imageView0;
    protected final Button button1;
    protected final ImageView imageView1;
    protected final Button button2;
    protected final ImageView imageView2;
    protected final Button button3;
    protected final ImageView imageView3;
    protected final Button button4;
    protected final ImageView imageView4;
    protected final Button button5;
    protected final ImageView imageView5;
    protected final Button button6;
    protected final ImageView imageView6;
    protected final TabPane tabPane;
    protected final Tab tab;
    protected final ScrollPane scrollPane;
    protected final VBox vBox;
    protected final GridPane gridPane0;
    protected final Text text;
    protected final ColumnConstraints columnConstraints8;
    protected final RowConstraints rowConstraints0;
    protected final AnchorPane anchorPane0;
    protected final VBox vBox0;
    protected final Text text0;
    protected final GridPane gridPane1;
    protected final Text text1;
    protected final Text text2;
    protected final Text text3;
    protected final Text text4;
    protected final Text text5;
    protected final Text text6;
    protected final Text text7;
    protected final Text text8;
    protected final TextField textField;
    protected final TextField textField0;
    protected final TextField textField1;
    protected final ComboBox comboBox;
    protected final ComboBox comboBox0;
    protected final ComboBox comboBox1;
    protected final ComboBox comboBox2;
    protected final Text text9;
    protected final Button button7;
    protected final ColumnConstraints columnConstraints9;
    protected final ColumnConstraints columnConstraints10;
    protected final ColumnConstraints columnConstraints11;
    protected final ColumnConstraints columnConstraints12;
    protected final ColumnConstraints columnConstraints13;
    protected final RowConstraints rowConstraints1;
    protected final RowConstraints rowConstraints2;
    protected final RowConstraints rowConstraints3;
    protected final RowConstraints rowConstraints4;
    protected final RowConstraints rowConstraints5;
    protected final RowConstraints rowConstraints6;
    protected final AnchorPane anchorPane1;
    protected final VBox vBox1;
    protected final Text text10;
    protected final Text text11;
    protected final GridPane gridPane2;
    protected final ColumnConstraints columnConstraints14;
    protected final ColumnConstraints columnConstraints15;
    protected final ColumnConstraints columnConstraints16;
    protected final RowConstraints rowConstraints7;
    protected final RowConstraints rowConstraints8;
    protected final Button button8;
    protected final Text text12;
    protected final Text text13;
    protected final TableView tableView;
    protected final TableColumn tableColumn;
    protected final TableColumn tableColumn0;
    protected final TableColumn tableColumn1;
    protected final TableColumn tableColumn2;
    protected final Text text14;
    protected final AnchorPane anchorPane2;
    protected final VBox vBox2;
    protected final Text text15;
    protected final GridPane gridPane3;
    protected final Text text16;
    protected final Button button9;
    protected final ImageView imageView7;
    protected final Text text17;
    protected final Text text18;
    protected final ImageView imageView8;
    protected final ImageView imageView9;
    protected final Button button10;
    protected final Button button11;
    protected final Text text19;
    protected final ComboBox comboBox3;
    protected final ColumnConstraints columnConstraints17;
    protected final ColumnConstraints columnConstraints18;
    protected final ColumnConstraints columnConstraints19;
    protected final RowConstraints rowConstraints9;
    protected final RowConstraints rowConstraints10;
    protected final RowConstraints rowConstraints11;
    protected final RowConstraints rowConstraints12;
    protected final Text text110;
    protected final Tab tab0;
    protected final ScrollPane scrollPane0;
    protected final SplitPane splitPane;
    protected final AnchorPane anchorPane3;
    protected final ScrollPane scrollPane1;
    protected final VBox vBox3;
    protected final GridPane gridPane4;
    protected final Text text111;
    protected final ColumnConstraints columnConstraints110;
    protected final RowConstraints rowConstraints13;
    protected final AnchorPane anchorPane4;
    protected final VBox vBox4;
    protected final TableView tableView0;
    protected final TableColumn tableColumn3;
    protected final TableColumn tableColumn4;
    protected final TableColumn tableColumn5;
    protected final Text text112;
    protected final GridPane gridPane5;
    protected final Text text113;
    protected final TextField textField2;
    protected final TextField textField3;
    protected final Button button12;
    protected final Button button13;
    protected final Text text114;
    protected final ColumnConstraints columnConstraints111;
    protected final ColumnConstraints columnConstraints112;
    protected final ColumnConstraints columnConstraints113;
    protected final ColumnConstraints columnConstraints114;
    protected final RowConstraints rowConstraints14;
    protected final RowConstraints rowConstraints15;
    protected final RowConstraints rowConstraints16;
    protected final AnchorPane anchorPane5;
    protected final ScrollPane scrollPane2;
    protected final VBox vBox5;
    protected final GridPane gridPane6;
    protected final Text text115;
    protected final ColumnConstraints columnConstraints115;
    protected final RowConstraints rowConstraints17;
    protected final AnchorPane anchorPane6;
    protected final VBox vBox6;
    protected final TableView tableView1;
    protected final TableColumn tableColumn6;
    protected final TableColumn tableColumn7;
    protected final TableColumn tableColumn8;
    protected final GridPane gridPane7;
    protected final Text text116;
    protected final Text text117;
    protected final ComboBox comboBox4;
    protected final ComboBox comboBox5;
    protected final ColumnConstraints columnConstraints116;
    protected final ColumnConstraints columnConstraints117;
    protected final RowConstraints rowConstraints18;
    protected final RowConstraints rowConstraints19;
    protected final Tab tab1;
    protected final ScrollPane scrollPane3;
    protected final VBox vBox7;
    protected final GridPane gridPane8;
    protected final ColumnConstraints columnConstraints118;
    protected final RowConstraints rowConstraints110;
    protected final Text text118;
    protected final AnchorPane anchorPane7;
    protected final TableView tableView2;
    protected final TableColumn tableColumn9;
    protected final TableColumn tableColumn10;
    protected final TableColumn tableColumn11;
    protected final TableColumn tableColumn12;
    protected final TableColumn tableColumn13;
    protected final AnchorPane anchorPane8;
    protected final VBox vBox8;
    protected final Text text119;
    protected final GridPane gridPane9;
    protected final Text text1110;
    protected final Text text1111;
    protected final Text text1112;
    protected final Text text1113;
    protected final TextField textField4;
    protected final TextField textField5;
    protected final TextField textField6;
    protected final TextField textField7;
    protected final Button button14;
    protected final Button button15;
    protected final ComboBox comboBox6;
    protected final ComboBox comboBox7;
    protected final Text text1114;
    protected final Text text1115;
    protected final ColumnConstraints columnConstraints119;
    protected final ColumnConstraints columnConstraints1110;
    protected final RowConstraints rowConstraints111;
    protected final RowConstraints rowConstraints112;
    protected final RowConstraints rowConstraints113;
    protected final RowConstraints rowConstraints114;
    protected final RowConstraints rowConstraints115;
    protected final RowConstraints rowConstraints116;
    protected final RowConstraints rowConstraints117;
    protected final Tab tab2;
    protected final ScrollPane scrollPane4;
    protected final VBox vBox9;
    protected final GridPane gridPane10;
    protected final Text text1116;
    protected final ColumnConstraints columnConstraints1111;
    protected final RowConstraints rowConstraints118;
    protected final AnchorPane anchorPane9;
    protected final VBox vBox10;
    protected final Text text1117;
    protected final GridPane gridPane11;
    protected final Text text1118;
    protected final Text text1119;
    protected final DatePicker datePicker;
    protected final DatePicker datePicker0;
    protected final ColumnConstraints columnConstraints1112;
    protected final ColumnConstraints columnConstraints1113;
    protected final ColumnConstraints columnConstraints1114;
    protected final ColumnConstraints columnConstraints1115;
    protected final RowConstraints rowConstraints119;
    protected final AnchorPane anchorPane10;
    protected final VBox vBox11;
    protected final Text text11110;
    protected final TableView tableView3;
    protected final TableColumn tableColumn14;
    protected final TableColumn tableColumn15;
    protected final TableColumn tableColumn16;
    protected final TableColumn tableColumn17;
    protected final AnchorPane anchorPane11;
    protected final VBox vBox12;
    protected final Text text11111;
    protected final GridPane gridPane12;
    protected final Text text11112;
    protected final Text text11113;
    protected final Text text11114;
    protected final Text text11115;
    protected final TextField textField8;
    protected final TextField textField9;
    protected final TextField textField10;
    protected final TextField textField11;
    protected final Button button16;
    protected final Button button17;
    protected final Text text11116;
    protected final Text text11117;
    protected final Text text11118;
    protected final DatePicker datePicker1;
    protected final ComboBox comboBox8;
    protected final TextField textField12;
    protected final ColumnConstraints columnConstraints1116;
    protected final ColumnConstraints columnConstraints1117;
    protected final RowConstraints rowConstraints1110;
    protected final RowConstraints rowConstraints1111;
    protected final RowConstraints rowConstraints1112;
    protected final RowConstraints rowConstraints1113;
    protected final RowConstraints rowConstraints1114;
    protected final RowConstraints rowConstraints1115;
    protected final RowConstraints rowConstraints1116;
    protected final RowConstraints rowConstraints1117;
    protected final Tab tab3;
    protected final ScrollPane scrollPane5;
    protected final VBox vBox13;
    protected final GridPane gridPane13;
    protected final Text text11119;
    protected final ColumnConstraints columnConstraints1118;
    protected final RowConstraints rowConstraints1118;
    protected final AnchorPane anchorPane12;
    protected final VBox vBox14;
    protected final Text text111110;
    protected final TableView tableView4;
    protected final TableColumn tableColumn18;
    protected final TableColumn tableColumn19;
    protected final TableColumn tableColumn110;
    protected final TableColumn tableColumn111;
    protected final Text text111111;
    protected final GridPane gridPane14;
    protected final Text text111112;
    protected final TextField textField13;
    protected final TextField textField14;
    protected final Button button18;
    protected final Button button19;
    protected final Text text111113;
    protected final Text text111114;
    protected final Text text111115;
    protected final Circle circle;
    protected final Circle circle0;
    protected final Text text111116;
    protected final Text text111117;
    protected final ColumnConstraints columnConstraints1119;
    protected final ColumnConstraints columnConstraints11110;
    protected final ColumnConstraints columnConstraints11111;
    protected final ColumnConstraints columnConstraints11112;
    protected final RowConstraints rowConstraints1119;
    protected final RowConstraints rowConstraints11110;
    protected final RowConstraints rowConstraints11111;
    protected final RowConstraints rowConstraints11112;
    protected final AnchorPane anchorPane13;
    protected final VBox vBox15;
    protected final Text text111118;
    protected final TableView tableView5;
    protected final TableColumn tableColumn112;
    protected final TableColumn tableColumn113;
    protected final TableColumn tableColumn114;
    protected final TableColumn tableColumn115;
    protected final Text text111119;
    protected final GridPane gridPane15;
    protected final Text text1111110;
    protected final Text text1111111;
    protected final TextField textField15;
    protected final TextField textField16;
    protected final TextField textField17;
    protected final Button button110;
    protected final Button button111;
    protected final Text text1111112;
    protected final Text text1111113;
    protected final TextField textField18;
    protected final ColumnConstraints columnConstraints11113;
    protected final ColumnConstraints columnConstraints11114;
    protected final RowConstraints rowConstraints11113;
    protected final RowConstraints rowConstraints11114;
    protected final RowConstraints rowConstraints11115;
    protected final RowConstraints rowConstraints11116;
    protected final RowConstraints rowConstraints11117;

    public SeveralTabsBase() {

        anchorPane = new AnchorPane();
        gridPane = new GridPane();
        columnConstraints = new ColumnConstraints();
        columnConstraints0 = new ColumnConstraints();
        columnConstraints1 = new ColumnConstraints();
        columnConstraints2 = new ColumnConstraints();
        columnConstraints3 = new ColumnConstraints();
        columnConstraints4 = new ColumnConstraints();
        columnConstraints5 = new ColumnConstraints();
        columnConstraints6 = new ColumnConstraints();
        columnConstraints7 = new ColumnConstraints();
        rowConstraints = new RowConstraints();
        button = new Button();
        imageView = new ImageView();
        button0 = new Button();
        imageView0 = new ImageView();
        button1 = new Button();
        imageView1 = new ImageView();
        button2 = new Button();
        imageView2 = new ImageView();
        button3 = new Button();
        imageView3 = new ImageView();
        button4 = new Button();
        imageView4 = new ImageView();
        button5 = new Button();
        imageView5 = new ImageView();
        button6 = new Button();
        imageView6 = new ImageView();
        tabPane = new TabPane();
        tab = new Tab();
        scrollPane = new ScrollPane();
        vBox = new VBox();
        gridPane0 = new GridPane();
        text = new Text();
        columnConstraints8 = new ColumnConstraints();
        rowConstraints0 = new RowConstraints();
        anchorPane0 = new AnchorPane();
        vBox0 = new VBox();
        text0 = new Text();
        gridPane1 = new GridPane();
        text1 = new Text();
        text2 = new Text();
        text3 = new Text();
        text4 = new Text();
        text5 = new Text();
        text6 = new Text();
        text7 = new Text();
        text8 = new Text();
        textField = new TextField();
        textField0 = new TextField();
        textField1 = new TextField();
        comboBox = new ComboBox();
        comboBox0 = new ComboBox();
        comboBox1 = new ComboBox();
        comboBox2 = new ComboBox();
        text9 = new Text();
        button7 = new Button();
        columnConstraints9 = new ColumnConstraints();
        columnConstraints10 = new ColumnConstraints();
        columnConstraints11 = new ColumnConstraints();
        columnConstraints12 = new ColumnConstraints();
        columnConstraints13 = new ColumnConstraints();
        rowConstraints1 = new RowConstraints();
        rowConstraints2 = new RowConstraints();
        rowConstraints3 = new RowConstraints();
        rowConstraints4 = new RowConstraints();
        rowConstraints5 = new RowConstraints();
        rowConstraints6 = new RowConstraints();
        anchorPane1 = new AnchorPane();
        vBox1 = new VBox();
        text10 = new Text();
        text11 = new Text();
        gridPane2 = new GridPane();
        columnConstraints14 = new ColumnConstraints();
        columnConstraints15 = new ColumnConstraints();
        columnConstraints16 = new ColumnConstraints();
        rowConstraints7 = new RowConstraints();
        rowConstraints8 = new RowConstraints();
        button8 = new Button();
        text12 = new Text();
        text13 = new Text();
        tableView = new TableView();
        tableColumn = new TableColumn();
        tableColumn0 = new TableColumn();
        tableColumn1 = new TableColumn();
        tableColumn2 = new TableColumn();
        text14 = new Text();
        anchorPane2 = new AnchorPane();
        vBox2 = new VBox();
        text15 = new Text();
        gridPane3 = new GridPane();
        text16 = new Text();
        button9 = new Button();
        imageView7 = new ImageView();
        text17 = new Text();
        text18 = new Text();
        imageView8 = new ImageView();
        imageView9 = new ImageView();
        button10 = new Button();
        button11 = new Button();
        text19 = new Text();
        comboBox3 = new ComboBox();
        columnConstraints17 = new ColumnConstraints();
        columnConstraints18 = new ColumnConstraints();
        columnConstraints19 = new ColumnConstraints();
        rowConstraints9 = new RowConstraints();
        rowConstraints10 = new RowConstraints();
        rowConstraints11 = new RowConstraints();
        rowConstraints12 = new RowConstraints();
        text110 = new Text();
        tab0 = new Tab();
        scrollPane0 = new ScrollPane();
        splitPane = new SplitPane();
        anchorPane3 = new AnchorPane();
        scrollPane1 = new ScrollPane();
        vBox3 = new VBox();
        gridPane4 = new GridPane();
        text111 = new Text();
        columnConstraints110 = new ColumnConstraints();
        rowConstraints13 = new RowConstraints();
        anchorPane4 = new AnchorPane();
        vBox4 = new VBox();
        tableView0 = new TableView();
        tableColumn3 = new TableColumn();
        tableColumn4 = new TableColumn();
        tableColumn5 = new TableColumn();
        text112 = new Text();
        gridPane5 = new GridPane();
        text113 = new Text();
        textField2 = new TextField();
        textField3 = new TextField();
        button12 = new Button();
        button13 = new Button();
        text114 = new Text();
        columnConstraints111 = new ColumnConstraints();
        columnConstraints112 = new ColumnConstraints();
        columnConstraints113 = new ColumnConstraints();
        columnConstraints114 = new ColumnConstraints();
        rowConstraints14 = new RowConstraints();
        rowConstraints15 = new RowConstraints();
        rowConstraints16 = new RowConstraints();
        anchorPane5 = new AnchorPane();
        scrollPane2 = new ScrollPane();
        vBox5 = new VBox();
        gridPane6 = new GridPane();
        text115 = new Text();
        columnConstraints115 = new ColumnConstraints();
        rowConstraints17 = new RowConstraints();
        anchorPane6 = new AnchorPane();
        vBox6 = new VBox();
        tableView1 = new TableView();
        tableColumn6 = new TableColumn();
        tableColumn7 = new TableColumn();
        tableColumn8 = new TableColumn();
        gridPane7 = new GridPane();
        text116 = new Text();
        text117 = new Text();
        comboBox4 = new ComboBox();
        comboBox5 = new ComboBox();
        columnConstraints116 = new ColumnConstraints();
        columnConstraints117 = new ColumnConstraints();
        rowConstraints18 = new RowConstraints();
        rowConstraints19 = new RowConstraints();
        tab1 = new Tab();
        scrollPane3 = new ScrollPane();
        vBox7 = new VBox();
        gridPane8 = new GridPane();
        columnConstraints118 = new ColumnConstraints();
        rowConstraints110 = new RowConstraints();
        text118 = new Text();
        anchorPane7 = new AnchorPane();
        tableView2 = new TableView();
        tableColumn9 = new TableColumn();
        tableColumn10 = new TableColumn();
        tableColumn11 = new TableColumn();
        tableColumn12 = new TableColumn();
        tableColumn13 = new TableColumn();
        anchorPane8 = new AnchorPane();
        vBox8 = new VBox();
        text119 = new Text();
        gridPane9 = new GridPane();
        text1110 = new Text();
        text1111 = new Text();
        text1112 = new Text();
        text1113 = new Text();
        textField4 = new TextField();
        textField5 = new TextField();
        textField6 = new TextField();
        textField7 = new TextField();
        button14 = new Button();
        button15 = new Button();
        comboBox6 = new ComboBox();
        comboBox7 = new ComboBox();
        text1114 = new Text();
        text1115 = new Text();
        columnConstraints119 = new ColumnConstraints();
        columnConstraints1110 = new ColumnConstraints();
        rowConstraints111 = new RowConstraints();
        rowConstraints112 = new RowConstraints();
        rowConstraints113 = new RowConstraints();
        rowConstraints114 = new RowConstraints();
        rowConstraints115 = new RowConstraints();
        rowConstraints116 = new RowConstraints();
        rowConstraints117 = new RowConstraints();
        tab2 = new Tab();
        scrollPane4 = new ScrollPane();
        vBox9 = new VBox();
        gridPane10 = new GridPane();
        text1116 = new Text();
        columnConstraints1111 = new ColumnConstraints();
        rowConstraints118 = new RowConstraints();
        anchorPane9 = new AnchorPane();
        vBox10 = new VBox();
        text1117 = new Text();
        gridPane11 = new GridPane();
        text1118 = new Text();
        text1119 = new Text();
        datePicker = new DatePicker();
        datePicker0 = new DatePicker();
        columnConstraints1112 = new ColumnConstraints();
        columnConstraints1113 = new ColumnConstraints();
        columnConstraints1114 = new ColumnConstraints();
        columnConstraints1115 = new ColumnConstraints();
        rowConstraints119 = new RowConstraints();
        anchorPane10 = new AnchorPane();
        vBox11 = new VBox();
        text11110 = new Text();
        tableView3 = new TableView();
        tableColumn14 = new TableColumn();
        tableColumn15 = new TableColumn();
        tableColumn16 = new TableColumn();
        tableColumn17 = new TableColumn();
        anchorPane11 = new AnchorPane();
        vBox12 = new VBox();
        text11111 = new Text();
        gridPane12 = new GridPane();
        text11112 = new Text();
        text11113 = new Text();
        text11114 = new Text();
        text11115 = new Text();
        textField8 = new TextField();
        textField9 = new TextField();
        textField10 = new TextField();
        textField11 = new TextField();
        button16 = new Button();
        button17 = new Button();
        text11116 = new Text();
        text11117 = new Text();
        text11118 = new Text();
        datePicker1 = new DatePicker();
        comboBox8 = new ComboBox();
        textField12 = new TextField();
        columnConstraints1116 = new ColumnConstraints();
        columnConstraints1117 = new ColumnConstraints();
        rowConstraints1110 = new RowConstraints();
        rowConstraints1111 = new RowConstraints();
        rowConstraints1112 = new RowConstraints();
        rowConstraints1113 = new RowConstraints();
        rowConstraints1114 = new RowConstraints();
        rowConstraints1115 = new RowConstraints();
        rowConstraints1116 = new RowConstraints();
        rowConstraints1117 = new RowConstraints();
        tab3 = new Tab();
        scrollPane5 = new ScrollPane();
        vBox13 = new VBox();
        gridPane13 = new GridPane();
        text11119 = new Text();
        columnConstraints1118 = new ColumnConstraints();
        rowConstraints1118 = new RowConstraints();
        anchorPane12 = new AnchorPane();
        vBox14 = new VBox();
        text111110 = new Text();
        tableView4 = new TableView();
        tableColumn18 = new TableColumn();
        tableColumn19 = new TableColumn();
        tableColumn110 = new TableColumn();
        tableColumn111 = new TableColumn();
        text111111 = new Text();
        gridPane14 = new GridPane();
        text111112 = new Text();
        textField13 = new TextField();
        textField14 = new TextField();
        button18 = new Button();
        button19 = new Button();
        text111113 = new Text();
        text111114 = new Text();
        text111115 = new Text();
        circle = new Circle();
        circle0 = new Circle();
        text111116 = new Text();
        text111117 = new Text();
        columnConstraints1119 = new ColumnConstraints();
        columnConstraints11110 = new ColumnConstraints();
        columnConstraints11111 = new ColumnConstraints();
        columnConstraints11112 = new ColumnConstraints();
        rowConstraints1119 = new RowConstraints();
        rowConstraints11110 = new RowConstraints();
        rowConstraints11111 = new RowConstraints();
        rowConstraints11112 = new RowConstraints();
        anchorPane13 = new AnchorPane();
        vBox15 = new VBox();
        text111118 = new Text();
        tableView5 = new TableView();
        tableColumn112 = new TableColumn();
        tableColumn113 = new TableColumn();
        tableColumn114 = new TableColumn();
        tableColumn115 = new TableColumn();
        text111119 = new Text();
        gridPane15 = new GridPane();
        text1111110 = new Text();
        text1111111 = new Text();
        textField15 = new TextField();
        textField16 = new TextField();
        textField17 = new TextField();
        button110 = new Button();
        button111 = new Button();
        text1111112 = new Text();
        text1111113 = new Text();
        textField18 = new TextField();
        columnConstraints11113 = new ColumnConstraints();
        columnConstraints11114 = new ColumnConstraints();
        rowConstraints11113 = new RowConstraints();
        rowConstraints11114 = new RowConstraints();
        rowConstraints11115 = new RowConstraints();
        rowConstraints11116 = new RowConstraints();
        rowConstraints11117 = new RowConstraints();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(1080.0);
        setPrefWidth(1000.0);
        setStyle(Messages.getString("key0")); //$NON-NLS-1$
        getStylesheets().add(Messages.getString("key1")); //$NON-NLS-1$

        anchorPane.setBlendMode(javafx.scene.effect.BlendMode.HARD_LIGHT);

        AnchorPane.setLeftAnchor(gridPane, 0.0);
        AnchorPane.setRightAnchor(gridPane, 0.0);
        AnchorPane.setTopAnchor(gridPane, 0.0);
        gridPane.setHgap(5.0);
        gridPane.setLayoutY(15.0);
        gridPane.setStyle(Messages.getString("key2")); //$NON-NLS-1$
        gridPane.setVgap(5.0);

        columnConstraints.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints0.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints1.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints2.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints3.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints4.setHgrow(javafx.scene.layout.Priority.ALWAYS);

        columnConstraints5.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints6.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints7.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints.setMinHeight(10.0);
        rowConstraints.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        button.setMnemonicParsing(false);
        button.setStyle(Messages.getString("key3")); //$NON-NLS-1$

        imageView.setFitHeight(40.0);
        imageView.setFitWidth(100.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        // imageView.setImage(new Image(getClass().getResource("../Resources/Icons/New%20copy.png").toExternalForm()));
        imageView.setImage(getImage(Messages.getString("key4"))); //$NON-NLS-1$
        button.setGraphic(imageView);

        GridPane.setColumnIndex(button0, 1);
        button0.setMnemonicParsing(false);
        button0.setStyle(Messages.getString("key5")); //$NON-NLS-1$

        imageView0.setFitHeight(40.0);
        imageView0.setFitWidth(55.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        // imageView0.setImage(new Image(getClass().getResource("../Resources/Icons/Folder%20copy.png").toExternalForm()));
        imageView0.setImage(getImage(Messages.getString("key6"))); //$NON-NLS-1$
        button0.setGraphic(imageView0);

        GridPane.setColumnIndex(button1, 2);
        button1.setMnemonicParsing(false);
        button1.setStyle(Messages.getString("key7")); //$NON-NLS-1$

        imageView1.setFitHeight(40.0);
        imageView1.setFitWidth(200.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        // imageView1.setImage(new Image(getClass().getResource("../Resources/Icons/Floppy%20copy.png").toExternalForm()));
        imageView1.setImage(getImage(Messages.getString("key8"))); //$NON-NLS-1$
        button1.setGraphic(imageView1);

        GridPane.setColumnIndex(button2, 3);
        button2.setMnemonicParsing(false);
        button2.setStyle(Messages.getString("key9")); //$NON-NLS-1$

        imageView2.setFitHeight(40.0);
        imageView2.setFitWidth(200.0);
        imageView2.setPickOnBounds(true);
        imageView2.setPreserveRatio(true);
        // imageView2.setImage(new Image(getClass().getResource("../Resources/Icons/FloppyDown%20copy.png").toExternalForm()));
        imageView2.setImage(getImage(Messages.getString("key10"))); //$NON-NLS-1$
        button2.setGraphic(imageView2);

        GridPane.setColumnIndex(button3, 4);
        button3.setMnemonicParsing(false);
        button3.setStyle(Messages.getString("key11")); //$NON-NLS-1$

        imageView3.setFitHeight(40.0);
        imageView3.setFitWidth(200.0);
        imageView3.setPickOnBounds(true);
        imageView3.setPreserveRatio(true);
        imageView3.setImage(getImage(Messages.getString("key12"))); //$NON-NLS-1$
        // imageView3.setImage(new Image(getClass().getResource("../Resources/Icons/Export%20copy.png").toExternalForm()));
        button3.setGraphic(imageView3);

        GridPane.setColumnIndex(button4, 6);
        GridPane.setHalignment(button4, javafx.geometry.HPos.RIGHT);
        button4.setMnemonicParsing(false);
        button4.setStyle(Messages.getString("key13")); //$NON-NLS-1$

        imageView4.setFitHeight(40.0);
        imageView4.setFitWidth(200.0);
        imageView4.setPickOnBounds(true);
        imageView4.setPreserveRatio(true);
        imageView4.setImage(getImage(Messages.getString("key14"))); //$NON-NLS-1$
        // imageView4.setImage(new Image(getClass().getResource("../Resources/Icons/Undo%20copy.png").toExternalForm()));
        button4.setGraphic(imageView4);

        GridPane.setColumnIndex(button5, 7);
        GridPane.setHalignment(button5, javafx.geometry.HPos.RIGHT);
        button5.setMnemonicParsing(false);
        button5.setStyle(Messages.getString("key15")); //$NON-NLS-1$

        imageView5.setFitHeight(40.0);
        imageView5.setFitWidth(200.0);
        imageView5.setPickOnBounds(true);
        imageView5.setPreserveRatio(true);
        imageView5.setImage(getImage(Messages.getString("key16"))); //$NON-NLS-1$
        // imageView5.setImage(new Image(getClass().getResource("../Resources/Icons/Redo%20copy.png").toExternalForm()));
        button5.setGraphic(imageView5);

        GridPane.setColumnIndex(button6, 8);
        GridPane.setHalignment(button6, javafx.geometry.HPos.RIGHT);
        button6.setMnemonicParsing(false);
        button6.setStyle(Messages.getString("key17")); //$NON-NLS-1$

        imageView6.setFitHeight(40.0);
        imageView6.setFitWidth(200.0);
        imageView6.setPickOnBounds(true);
        imageView6.setPreserveRatio(true);
        imageView6.setImage(getImage(Messages.getString("key18"))); //$NON-NLS-1$
        // imageView6.setImage(new Image(getClass().getResource("../Resources/Icons/Book%20copy.png").toExternalForm()));
        button6.setGraphic(imageView6);
        gridPane.setPadding(new Insets(5.0));

        VBox.setVgrow(tabPane, javafx.scene.layout.Priority.ALWAYS);
        tabPane.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        tabPane.setOpacity(0.93);
        tabPane.setPrefHeight(200.0);
        tabPane.setPrefWidth(200.0);
        tabPane.getStylesheets().add(Messages.getString("key19")); //$NON-NLS-1$
        tabPane.setTabClosingPolicy(javafx.scene.control.TabPane.TabClosingPolicy.UNAVAILABLE);

        tab.setStyle(Messages.getString("key20")); //$NON-NLS-1$
        tab.setText(Messages.getString("key21")); //$NON-NLS-1$

        scrollPane.setFitToHeight(true);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefViewportHeight(1020.0);
        scrollPane.setPrefViewportWidth(1000.0);

        vBox.setSpacing(5.0);
        vBox.setStyle(Messages.getString("key22")); //$NON-NLS-1$

        gridPane0.setAlignment(javafx.geometry.Pos.CENTER);

        GridPane.setHalignment(text, javafx.geometry.HPos.CENTER);
        text.setFill(javafx.scene.paint.Color.valueOf(Messages.getString("key23"))); //$NON-NLS-1$
        text.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text.setStrokeWidth(0.0);
        text.setStyle(Messages.getString("key24")); //$NON-NLS-1$
        text.setText(Messages.getString("key25")); //$NON-NLS-1$
        text.setFont(new Font(Messages.getString("key26"), 50.0)); //$NON-NLS-1$
        GridPane.setMargin(text, new Insets(5.0, 0.0, 5.0, 0.0));

        columnConstraints8.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints8.setMinWidth(0.0);

        rowConstraints0.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        anchorPane0.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane0.setStyle(Messages.getString("key27")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox0, 0.0);
        AnchorPane.setLeftAnchor(vBox0, 0.0);
        AnchorPane.setRightAnchor(vBox0, 0.0);
        AnchorPane.setTopAnchor(vBox0, 0.0);
        vBox0.setPrefHeight(251.0);
        vBox0.setPrefWidth(990.0);

        text0.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text0.setStrokeWidth(0.0);
        text0.setStyle(Messages.getString("key28")); //$NON-NLS-1$
        text0.setText(Messages.getString("key29")); //$NON-NLS-1$
        text0.setFont(new Font(Messages.getString("key30"), 13.0)); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(gridPane1, 0.0);
        AnchorPane.setLeftAnchor(gridPane1, 0.0);
        AnchorPane.setRightAnchor(gridPane1, 0.0);
        AnchorPane.setTopAnchor(gridPane1, 0.0);
        gridPane1.setCacheShape(false);
        gridPane1.setCenterShape(false);
        gridPane1.setFocusTraversable(true);
        gridPane1.setHgap(10.0);
        gridPane1.setScaleShape(false);
        gridPane1.setVgap(10.0);

        text1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1.setStrokeWidth(0.0);
        text1.setText(Messages.getString("key31")); //$NON-NLS-1$

        GridPane.setRowIndex(text2, 1);
        text2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text2.setStrokeWidth(0.0);
        text2.setText(Messages.getString("key32")); //$NON-NLS-1$

        GridPane.setColumnIndex(text3, 3);
        GridPane.setHalignment(text3, javafx.geometry.HPos.LEFT);
        text3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text3.setStrokeWidth(0.0);
        text3.setText(Messages.getString("key33")); //$NON-NLS-1$

        GridPane.setColumnIndex(text4, 3);
        GridPane.setHalignment(text4, javafx.geometry.HPos.LEFT);
        GridPane.setRowIndex(text4, 1);
        text4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text4.setStrokeWidth(0.0);
        text4.setText(Messages.getString("key34")); //$NON-NLS-1$

        GridPane.setRowIndex(text5, 2);
        text5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text5.setStrokeWidth(0.0);
        text5.setText(Messages.getString("key35")); //$NON-NLS-1$

        GridPane.setRowIndex(text6, 3);
        text6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text6.setStrokeWidth(0.0);
        text6.setText(Messages.getString("key36")); //$NON-NLS-1$

        GridPane.setRowIndex(text7, 4);
        text7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text7.setStrokeWidth(0.0);
        text7.setText(Messages.getString("key37")); //$NON-NLS-1$

        GridPane.setRowIndex(text8, 5);
        text8.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text8.setStrokeWidth(0.0);
        text8.setText(Messages.getString("key38")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField, 1);
        GridPane.setColumnSpan(textField, 2147483647);
        GridPane.setRowIndex(textField, 2);
        textField.setPromptText(Messages.getString("key39")); //$NON-NLS-1$
        textField.setStyle(Messages.getString("key40")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField0, 1);
        GridPane.setColumnSpan(textField0, 2147483647);
        GridPane.setRowIndex(textField0, 3);
        textField0.setPromptText(Messages.getString("key41")); //$NON-NLS-1$
        textField0.setStyle(Messages.getString("key42")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField1, 1);
        GridPane.setColumnSpan(textField1, 2147483647);
        GridPane.setRowIndex(textField1, 4);
        textField1.setPromptText(Messages.getString("key43")); //$NON-NLS-1$
        textField1.setStyle(Messages.getString("key44")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox, 1);
        comboBox.setPrefWidth(150.0);
        comboBox.setPromptText(Messages.getString("key45")); //$NON-NLS-1$
        comboBox.setStyle(Messages.getString("key46")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox0, 1);
        GridPane.setRowIndex(comboBox0, 1);
        comboBox0.setPrefWidth(150.0);
        comboBox0.setPromptText(Messages.getString("key47")); //$NON-NLS-1$
        comboBox0.setStyle(Messages.getString("key48")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox1, 4);
        GridPane.setHalignment(comboBox1, javafx.geometry.HPos.RIGHT);
        comboBox1.setPrefWidth(150.0);
        comboBox1.setPromptText(Messages.getString("key49")); //$NON-NLS-1$
        comboBox1.setStyle(Messages.getString("key50")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox2, 4);
        GridPane.setHalignment(comboBox2, javafx.geometry.HPos.RIGHT);
        GridPane.setRowIndex(comboBox2, 1);
        comboBox2.setPrefWidth(150.0);
        comboBox2.setPromptText(Messages.getString("key51")); //$NON-NLS-1$
        comboBox2.setStyle(Messages.getString("key52")); //$NON-NLS-1$

        GridPane.setColumnIndex(text9, 1);
        GridPane.setColumnSpan(text9, 3);
        GridPane.setHalignment(text9, javafx.geometry.HPos.CENTER);
        GridPane.setRowIndex(text9, 5);
        text9.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text9.setStrokeWidth(0.0);
        text9.setText(Messages.getString("key53")); //$NON-NLS-1$
        text9.setUnderline(true);

        GridPane.setColumnIndex(button7, 4);
        GridPane.setHalignment(button7, javafx.geometry.HPos.RIGHT);
        GridPane.setRowIndex(button7, 5);
        button7.setMnemonicParsing(false);
        button7.setStyle(Messages.getString("key54")); //$NON-NLS-1$
        button7.setText(Messages.getString("key55")); //$NON-NLS-1$

        columnConstraints9.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints9.setMaxWidth(938.9019165039062);

        columnConstraints10.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints10.setMinWidth(50.0);

        columnConstraints11.setHgrow(javafx.scene.layout.Priority.ALWAYS);
        columnConstraints11.setMaxWidth(561.8994140625);
        columnConstraints11.setMinWidth(0.0);
        columnConstraints11.setPrefWidth(304.5467529296875);

        columnConstraints12.setHgrow(javafx.scene.layout.Priority.NEVER);

        columnConstraints13.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints13.setMaxWidth(1777.0434799194336);
        columnConstraints13.setMinWidth(100.0);

        rowConstraints2.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints3.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints4.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints5.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints6.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        vBox0.setOpaqueInsets(new Insets(0.0));
        vBox0.setPadding(new Insets(10.0));

        anchorPane1.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane1.setStyle(Messages.getString("key56")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox1, 0.0);
        AnchorPane.setLeftAnchor(vBox1, 0.0);
        AnchorPane.setRightAnchor(vBox1, 0.0);
        AnchorPane.setTopAnchor(vBox1, 0.0);
        vBox1.setPrefHeight(180.0);
        vBox1.setPrefWidth(990.0);

        text10.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text10.setStrokeWidth(0.0);
        text10.setStyle(Messages.getString("key57")); //$NON-NLS-1$
        text10.setText(Messages.getString("key58")); //$NON-NLS-1$

        text11.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11.setStrokeWidth(0.0);
        text11.setStyle(Messages.getString("key59")); //$NON-NLS-1$
        text11.setText(Messages.getString("key60")); //$NON-NLS-1$

        VBox.setVgrow(gridPane2, javafx.scene.layout.Priority.ALWAYS);
        gridPane2.setHgap(10.0);
        gridPane2.setVgap(10.0);

        columnConstraints14.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints15.setHgrow(javafx.scene.layout.Priority.ALWAYS);

        columnConstraints16.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints7.setVgrow(javafx.scene.layout.Priority.ALWAYS);

        rowConstraints8.setVgrow(javafx.scene.layout.Priority.ALWAYS);

        GridPane.setColumnIndex(button8, 2);
        GridPane.setHalignment(button8, javafx.geometry.HPos.RIGHT);
        button8.setMnemonicParsing(false);
        button8.setStyle(Messages.getString("key61")); //$NON-NLS-1$
        button8.setText(Messages.getString("key62")); //$NON-NLS-1$

        GridPane.setColumnIndex(text12, 1);
        GridPane.setHalignment(text12, javafx.geometry.HPos.CENTER);
        text12.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text12.setStrokeWidth(0.0);
        text12.setText(Messages.getString("key63")); //$NON-NLS-1$
        text12.setUnderline(true);

        text13.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text13.setStrokeWidth(0.0);
        text13.setText(Messages.getString("key64")); //$NON-NLS-1$

        GridPane.setColumnIndex(tableView, 1);
        GridPane.setColumnSpan(tableView, 2);
        GridPane.setRowIndex(tableView, 1);
        tableView.setStyle(Messages.getString("key65")); //$NON-NLS-1$
        tableView.getStylesheets().add(Messages.getString("key66")); //$NON-NLS-1$

        tableColumn.setPrefWidth(75.0);
        tableColumn.setText(Messages.getString("key67")); //$NON-NLS-1$

        tableColumn0.setPrefWidth(75.0);
        // tableColumn0.setStyle("-fx-background-color: #553366;");
        tableColumn0.setText(Messages.getString("key68")); //$NON-NLS-1$

        tableColumn1.setPrefWidth(75.0);
        tableColumn1.setText(Messages.getString("key69")); //$NON-NLS-1$

        tableColumn2.setPrefWidth(75.0);
        tableColumn2.setText(Messages.getString("key70")); //$NON-NLS-1$
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        GridPane.setRowIndex(text14, 1);
        text14.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text14.setStrokeWidth(0.0);
        text14.setText(Messages.getString("key71")); //$NON-NLS-1$
        vBox1.setPadding(new Insets(10.0));

        anchorPane2.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane2.setStyle(Messages.getString("key72")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox2, 0.0);
        AnchorPane.setLeftAnchor(vBox2, 0.0);
        AnchorPane.setRightAnchor(vBox2, 0.0);
        AnchorPane.setTopAnchor(vBox2, 0.0);
        vBox2.setPrefHeight(151.0);
        vBox2.setPrefWidth(990.0);

        text15.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text15.setStrokeWidth(0.0);
        text15.setStyle(Messages.getString("key73")); //$NON-NLS-1$
        text15.setText(Messages.getString("key74")); //$NON-NLS-1$

        VBox.setVgrow(gridPane3, javafx.scene.layout.Priority.ALWAYS);
        gridPane3.setCacheShape(false);
        gridPane3.setCenterShape(false);
        gridPane3.setFocusTraversable(true);
        gridPane3.setHgap(10.0);
        gridPane3.setPrefWidth(998.0);
        gridPane3.setScaleShape(false);
        gridPane3.setVgap(10.0);

        text16.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text16.setStrokeWidth(0.0);
        text16.setText(Messages.getString("key75")); //$NON-NLS-1$

        GridPane.setColumnIndex(button9, 2);
        GridPane.setHalignment(button9, javafx.geometry.HPos.RIGHT);
        button9.setMnemonicParsing(false);
        button9.setStyle(Messages.getString("key76")); //$NON-NLS-1$
        button9.setText(Messages.getString("key77")); //$NON-NLS-1$

        GridPane.setColumnIndex(imageView7, 1);
        GridPane.setHalignment(imageView7, javafx.geometry.HPos.CENTER);
        imageView7.setFitHeight(150.0);
        imageView7.setFitWidth(200.0);
        imageView7.setPickOnBounds(true);
        imageView7.setPreserveRatio(true);
        imageView7.setImage(getImage(Messages.getString("key78"))); //$NON-NLS-1$


        GridPane.setRowIndex(text17, 1);
        text17.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text17.setStrokeWidth(0.0);
        text17.setText(Messages.getString("key79")); //$NON-NLS-1$

        GridPane.setRowIndex(text18, 2);
        text18.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text18.setStrokeWidth(0.0);
        text18.setText(Messages.getString("key80")); //$NON-NLS-1$

        GridPane.setColumnIndex(imageView8, 1);
        GridPane.setHalignment(imageView8, javafx.geometry.HPos.CENTER);
        GridPane.setRowIndex(imageView8, 1);
        imageView8.setFitHeight(150.0);
        imageView8.setFitWidth(200.0);
        imageView8.setPickOnBounds(true);
        imageView8.setPreserveRatio(true);
        imageView8.setImage(getImage(Messages.getString("key81"))); //$NON-NLS-1$

        GridPane.setColumnIndex(imageView9, 1);
        GridPane.setHalignment(imageView9, javafx.geometry.HPos.CENTER);
        GridPane.setRowIndex(imageView9, 2);
        imageView9.setFitHeight(150.0);
        imageView9.setFitWidth(200.0);
        imageView9.setPickOnBounds(true);
        imageView9.setPreserveRatio(true);
        imageView9.setImage(getImage(Messages.getString("key82"))); //$NON-NLS-1$

        GridPane.setColumnIndex(button10, 2);
        GridPane.setHalignment(button10, javafx.geometry.HPos.RIGHT);
        GridPane.setRowIndex(button10, 1);
        button10.setMnemonicParsing(false);
        button10.setStyle(Messages.getString("key83")); //$NON-NLS-1$
        button10.setText(Messages.getString("key84")); //$NON-NLS-1$

        GridPane.setColumnIndex(button11, 2);
        GridPane.setHalignment(button11, javafx.geometry.HPos.RIGHT);
        GridPane.setRowIndex(button11, 2);
        button11.setMnemonicParsing(false);
        button11.setStyle(Messages.getString("key85")); //$NON-NLS-1$
        button11.setText(Messages.getString("key86")); //$NON-NLS-1$

        GridPane.setRowIndex(text19, 3);
        text19.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text19.setStrokeWidth(0.0);
        text19.setText(Messages.getString("key87")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox3, 1);
        GridPane.setRowIndex(comboBox3, 3);
        comboBox3.setPrefWidth(150.0);
        comboBox3.setPromptText(Messages.getString("key88")); //$NON-NLS-1$
        comboBox3.setStyle(Messages.getString("key89")); //$NON-NLS-1$

        columnConstraints17.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints18.setHgrow(javafx.scene.layout.Priority.ALWAYS);
        columnConstraints18.setMaxWidth(Double.MAX_VALUE);

        columnConstraints19.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints9.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints10.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints12.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        text110.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text110.setStrokeWidth(0.0);
        text110.setStyle(Messages.getString("key90")); //$NON-NLS-1$
        text110.setText(Messages.getString("key91")); //$NON-NLS-1$
        vBox2.setPadding(new Insets(10.0));
        vBox.setPadding(new Insets(5.0));
        scrollPane.setContent(vBox);
        tab.setContent(scrollPane);

        tab0.setStyle(Messages.getString("key92")); //$NON-NLS-1$
        tab0.setText(Messages.getString("key93")); //$NON-NLS-1$

        scrollPane0.setFitToHeight(true);
        scrollPane0.setFitToWidth(true);
        scrollPane0.setPrefViewportHeight(1020.0);
        scrollPane0.setPrefViewportWidth(1000.0);

        splitPane.setDividerPositions(0.5100200400801603);
        splitPane.setPrefHeight(160.0);
        splitPane.setPrefWidth(200.0);

        anchorPane3.setMinHeight(0.0);
        anchorPane3.setMinWidth(0.0);
        anchorPane3.setPrefHeight(160.0);
        anchorPane3.setPrefWidth(100.0);

        AnchorPane.setBottomAnchor(scrollPane1, 0.0);
        AnchorPane.setLeftAnchor(scrollPane1, 0.0);
        AnchorPane.setRightAnchor(scrollPane1, 0.0);
        AnchorPane.setTopAnchor(scrollPane1, 0.0);
        scrollPane1.setFitToHeight(true);
        scrollPane1.setFitToWidth(true);
        scrollPane1.setPrefViewportHeight(984.0);
        scrollPane1.setPrefViewportWidth(419.0);

        AnchorPane.setBottomAnchor(vBox3, 0.0);
        AnchorPane.setLeftAnchor(vBox3, 0.0);
        AnchorPane.setRightAnchor(vBox3, 0.0);
        AnchorPane.setTopAnchor(vBox3, 0.0);
        vBox3.setPrefHeight(984.0);
        vBox3.setPrefWidth(518.0);
        vBox3.setSpacing(5.0);
        vBox3.setStyle(Messages.getString("key94")); //$NON-NLS-1$

        gridPane4.setAlignment(javafx.geometry.Pos.CENTER);

        GridPane.setHalignment(text111, javafx.geometry.HPos.CENTER);
        text111.setFill(javafx.scene.paint.Color.valueOf(Messages.getString("key95"))); //$NON-NLS-1$
        text111.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111.setStrokeWidth(0.0);
        text111.setStyle(Messages.getString("key96")); //$NON-NLS-1$
        text111.setText(Messages.getString("key97")); //$NON-NLS-1$
        text111.setFont(new Font(Messages.getString("key98"), 50.0)); //$NON-NLS-1$
        GridPane.setMargin(text111, new Insets(5.0, 0.0, 5.0, 0.0));

        columnConstraints110.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints110.setMinWidth(0.0);

        rowConstraints13.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        anchorPane4.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane4.setStyle(Messages.getString("key99")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox4, 0.0);
        AnchorPane.setLeftAnchor(vBox4, 0.0);
        AnchorPane.setRightAnchor(vBox4, 0.0);
        AnchorPane.setTopAnchor(vBox4, 0.0);

        tableView0.setStyle(Messages.getString("key100")); //$NON-NLS-1$
        tableView0.getStylesheets().add(Messages.getString("key101")); //$NON-NLS-1$
        tableView0.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        tableColumn3.setPrefWidth(75.0);
        tableColumn3.setText(Messages.getString("key102")); //$NON-NLS-1$

        tableColumn4.setPrefWidth(75.0);
        // tableColumn4.setStyle("-fx-background-color: #553366;");
        tableColumn4.setText(Messages.getString("key103")); //$NON-NLS-1$

        tableColumn5.setPrefWidth(75.0);
        tableColumn5.setText(Messages.getString("key104")); //$NON-NLS-1$

        text112.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text112.setStrokeWidth(0.0);
        text112.setStyle(Messages.getString("key105")); //$NON-NLS-1$
        text112.setText(Messages.getString("key106")); //$NON-NLS-1$
        text112.setFont(new Font(Messages.getString("key107"), 13.0)); //$NON-NLS-1$
        VBox.setMargin(text112, new Insets(10.0, 0.0, 10.0, 0.0));

        AnchorPane.setBottomAnchor(gridPane5, 0.0);
        AnchorPane.setLeftAnchor(gridPane5, 0.0);
        AnchorPane.setRightAnchor(gridPane5, 0.0);
        AnchorPane.setTopAnchor(gridPane5, 0.0);
        gridPane5.setCacheShape(false);
        gridPane5.setCenterShape(false);
        gridPane5.setFocusTraversable(true);
        gridPane5.setHgap(10.0);
        gridPane5.setScaleShape(false);
        gridPane5.setVgap(10.0);

        text113.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text113.setStrokeWidth(0.0);
        text113.setText(Messages.getString("key108")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField2, 1);
        GridPane.setColumnSpan(textField2, 2147483647);
        GridPane.setRowIndex(textField2, 1);
        textField2.setPromptText(Messages.getString("key109")); //$NON-NLS-1$
        textField2.setStyle(Messages.getString("key110")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField3, 1);
        GridPane.setColumnSpan(textField3, 2147483647);
        textField3.setPromptText(Messages.getString("key111")); //$NON-NLS-1$
        textField3.setStyle(Messages.getString("key112")); //$NON-NLS-1$

        GridPane.setRowIndex(button12, 2);
        button12.setMaxWidth(100.0);
        button12.setMinWidth(100.0);
        button12.setMnemonicParsing(false);
        button12.setStyle(Messages.getString("key113")); //$NON-NLS-1$
        button12.setText(Messages.getString("key114")); //$NON-NLS-1$

        GridPane.setColumnIndex(button13, 1);
        GridPane.setRowIndex(button13, 2);
        button13.setMaxWidth(100.0);
        button13.setMnemonicParsing(false);
        button13.setStyle(Messages.getString("key115")); //$NON-NLS-1$
        button13.setText(Messages.getString("key116")); //$NON-NLS-1$

        GridPane.setRowIndex(text114, 1);
        text114.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text114.setStrokeWidth(0.0);
        text114.setText(Messages.getString("key117")); //$NON-NLS-1$

        columnConstraints111.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints111.setMaxWidth(938.9019165039062);

        columnConstraints112.setPrefWidth(200.0);

        columnConstraints113.setPrefWidth(120.0);

        columnConstraints114.setHgrow(javafx.scene.layout.Priority.ALWAYS);

        rowConstraints14.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints15.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints16.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        vBox4.setOpaqueInsets(new Insets(0.0));
        vBox4.setPadding(new Insets(10.0));
        vBox3.setPadding(new Insets(5.0));
        scrollPane1.setContent(vBox3);

        anchorPane5.setMinHeight(0.0);
        anchorPane5.setMinWidth(0.0);
        anchorPane5.setPrefHeight(160.0);
        anchorPane5.setPrefWidth(100.0);

        AnchorPane.setBottomAnchor(scrollPane2, 0.0);
        AnchorPane.setLeftAnchor(scrollPane2, 0.0);
        AnchorPane.setRightAnchor(scrollPane2, 0.0);
        AnchorPane.setTopAnchor(scrollPane2, 0.0);
        scrollPane2.setFitToHeight(true);
        scrollPane2.setFitToWidth(true);
        scrollPane2.setPrefViewportHeight(984.0);
        scrollPane2.setPrefViewportWidth(419.0);

        AnchorPane.setBottomAnchor(vBox5, 0.0);
        AnchorPane.setLeftAnchor(vBox5, 0.0);
        AnchorPane.setRightAnchor(vBox5, 0.0);
        AnchorPane.setTopAnchor(vBox5, 0.0);
        vBox5.setPrefHeight(984.0);
        vBox5.setPrefWidth(518.0);
        vBox5.setSpacing(5.0);
        vBox5.setStyle(Messages.getString("key118")); //$NON-NLS-1$

        gridPane6.setAlignment(javafx.geometry.Pos.CENTER);

        GridPane.setHalignment(text115, javafx.geometry.HPos.CENTER);
        text115.setFill(javafx.scene.paint.Color.valueOf(Messages.getString("key119"))); //$NON-NLS-1$
        text115.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text115.setStrokeWidth(0.0);
        text115.setStyle(Messages.getString("key120")); //$NON-NLS-1$
        text115.setText(Messages.getString("key121")); //$NON-NLS-1$
        text115.setFont(new Font(Messages.getString("key122"), 50.0)); //$NON-NLS-1$
        GridPane.setMargin(text115, new Insets(5.0, 0.0, 5.0, 0.0));

        columnConstraints115.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints115.setMinWidth(0.0);

        rowConstraints17.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        anchorPane6.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane6.setStyle(Messages.getString("key123")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox6, 0.0);
        AnchorPane.setLeftAnchor(vBox6, 0.0);
        AnchorPane.setRightAnchor(vBox6, 0.0);
        AnchorPane.setTopAnchor(vBox6, 0.0);

        tableView1.setStyle(Messages.getString("key124")); //$NON-NLS-1$
        tableView1.getStylesheets().add(Messages.getString("key125")); //$NON-NLS-1$
        tableView1.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        tableColumn6.setPrefWidth(75.0);
        tableColumn6.setText(Messages.getString("key126")); //$NON-NLS-1$

        tableColumn7.setPrefWidth(75.0);
        // tableColumn7.setStyle("-fx-background-color: #553366;");
        tableColumn7.setText(Messages.getString("key127")); //$NON-NLS-1$

        tableColumn8.setPrefWidth(75.0);
        tableColumn8.setText(Messages.getString("key128")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(gridPane7, 0.0);
        AnchorPane.setLeftAnchor(gridPane7, 0.0);
        AnchorPane.setRightAnchor(gridPane7, 0.0);
        AnchorPane.setTopAnchor(gridPane7, 0.0);
        gridPane7.setCacheShape(false);
        gridPane7.setCenterShape(false);
        gridPane7.setFocusTraversable(true);
        gridPane7.setHgap(10.0);
        gridPane7.setScaleShape(false);
        gridPane7.setVgap(10.0);

        text116.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text116.setStrokeWidth(0.0);
        text116.setText(Messages.getString("key129")); //$NON-NLS-1$

        GridPane.setRowIndex(text117, 1);
        text117.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text117.setStrokeWidth(0.0);
        text117.setText(Messages.getString("key130")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox4, 1);
        comboBox4.setPrefWidth(150.0);
        comboBox4.setPromptText(Messages.getString("key131")); //$NON-NLS-1$
        comboBox4.setStyle(Messages.getString("key132")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox5, 1);
        GridPane.setRowIndex(comboBox5, 1);
        comboBox5.setPrefWidth(150.0);
        comboBox5.setPromptText(Messages.getString("key133")); //$NON-NLS-1$
        comboBox5.setStyle(Messages.getString("key134")); //$NON-NLS-1$

        columnConstraints116.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints116.setMaxWidth(938.9019165039062);

        columnConstraints117.setPrefWidth(1000.0);

        rowConstraints18.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints19.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        gridPane7.setPadding(new Insets(10.0, 0.0, 0.0, 0.0));
        vBox6.setOpaqueInsets(new Insets(0.0));
        vBox6.setPadding(new Insets(10.0));
        vBox5.setPadding(new Insets(5.0));
        scrollPane2.setContent(vBox5);
        scrollPane0.setContent(splitPane);
        tab0.setContent(scrollPane0);

        tab1.setStyle(Messages.getString("key135")); //$NON-NLS-1$
        tab1.setText(Messages.getString("key136")); //$NON-NLS-1$

        scrollPane3.setFitToHeight(true);
        scrollPane3.setFitToWidth(true);
        scrollPane3.setPrefViewportHeight(1020.0);
        scrollPane3.setPrefViewportWidth(1000.0);

        vBox7.setSpacing(5.0);
        vBox7.setStyle(Messages.getString("key137")); //$NON-NLS-1$

        gridPane8.setAlignment(javafx.geometry.Pos.CENTER);

        columnConstraints118.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints118.setMinWidth(10.0);

        rowConstraints110.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        GridPane.setHalignment(text118, javafx.geometry.HPos.CENTER);
        text118.setFill(javafx.scene.paint.Color.valueOf(Messages.getString("key138"))); //$NON-NLS-1$
        text118.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text118.setStrokeWidth(0.0);
        text118.setStyle(Messages.getString("key139")); //$NON-NLS-1$
        text118.setText(Messages.getString("key140")); //$NON-NLS-1$
        text118.setFont(new Font(Messages.getString("key141"), 50.0)); //$NON-NLS-1$
        GridPane.setMargin(text118, new Insets(5.0, 0.0, 5.0, 0.0));

        anchorPane7.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane7.setStyle(Messages.getString("key142")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(tableView2, 10.0);
        AnchorPane.setLeftAnchor(tableView2, 10.0);
        AnchorPane.setRightAnchor(tableView2, 10.0);
        AnchorPane.setTopAnchor(tableView2, 10.0);
        tableView2.setStyle(Messages.getString("key143")); //$NON-NLS-1$
        tableView2.getStylesheets().add(Messages.getString("key144")); //$NON-NLS-1$
        tableView2.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        tableColumn9.setPrefWidth(75.0);
        tableColumn9.setText(Messages.getString("key145")); //$NON-NLS-1$

        tableColumn10.setPrefWidth(75.0);
        // tableColumn10.setStyle("-fx-background-color: #553366;");
        tableColumn10.setText(Messages.getString("key146")); //$NON-NLS-1$

        tableColumn11.setPrefWidth(75.0);
        tableColumn11.setText(Messages.getString("key147")); //$NON-NLS-1$

        tableColumn12.setPrefWidth(75.0);
        tableColumn12.setText(Messages.getString("key148")); //$NON-NLS-1$

        tableColumn13.setPrefWidth(75.0);
        tableColumn13.setText(Messages.getString("key149")); //$NON-NLS-1$

        anchorPane8.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane8.setStyle(Messages.getString("key150")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox8, 0.0);
        AnchorPane.setLeftAnchor(vBox8, 0.0);
        AnchorPane.setRightAnchor(vBox8, 0.0);
        AnchorPane.setTopAnchor(vBox8, 0.0);

        text119.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text119.setStrokeWidth(0.0);
        text119.setStyle(Messages.getString("key151")); //$NON-NLS-1$
        text119.setText(Messages.getString("key152")); //$NON-NLS-1$
        text119.setFont(new Font(Messages.getString("key153"), 13.0)); //$NON-NLS-1$
        VBox.setMargin(text119, new Insets(0.0, 0.0, 10.0, 0.0));

        AnchorPane.setBottomAnchor(gridPane9, 0.0);
        AnchorPane.setLeftAnchor(gridPane9, 0.0);
        AnchorPane.setRightAnchor(gridPane9, 0.0);
        AnchorPane.setTopAnchor(gridPane9, 0.0);
        gridPane9.setCacheShape(false);
        gridPane9.setCenterShape(false);
        gridPane9.setFocusTraversable(true);
        gridPane9.setHgap(10.0);
        gridPane9.setScaleShape(false);
        gridPane9.setVgap(10.0);

        text1110.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1110.setStrokeWidth(0.0);
        text1110.setText(Messages.getString("key154")); //$NON-NLS-1$

        GridPane.setRowIndex(text1111, 1);
        text1111.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1111.setStrokeWidth(0.0);
        text1111.setText(Messages.getString("key155")); //$NON-NLS-1$

        GridPane.setRowIndex(text1112, 2);
        text1112.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1112.setStrokeWidth(0.0);
        text1112.setText(Messages.getString("key156")); //$NON-NLS-1$

        GridPane.setRowIndex(text1113, 3);
        text1113.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1113.setStrokeWidth(0.0);
        text1113.setText(Messages.getString("key157")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField4, 1);
        GridPane.setColumnSpan(textField4, 2147483647);
        textField4.setPromptText(Messages.getString("key158")); //$NON-NLS-1$
        textField4.setStyle(Messages.getString("key159")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField5, 1);
        GridPane.setColumnSpan(textField5, 2147483647);
        GridPane.setRowIndex(textField5, 1);
        textField5.setPromptText(Messages.getString("key160")); //$NON-NLS-1$
        textField5.setStyle(Messages.getString("key161")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField6, 1);
        GridPane.setColumnSpan(textField6, 2147483647);
        GridPane.setRowIndex(textField6, 2);
        textField6.setPromptText(Messages.getString("key162")); //$NON-NLS-1$
        textField6.setStyle(Messages.getString("key163")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField7, 1);
        GridPane.setColumnSpan(textField7, 2147483647);
        GridPane.setRowIndex(textField7, 3);
        textField7.setPromptText(Messages.getString("key164")); //$NON-NLS-1$
        textField7.setStyle(Messages.getString("key165")); //$NON-NLS-1$

        GridPane.setRowIndex(button14, 6);
        button14.setMaxWidth(100.0);
        button14.setMinWidth(100.0);
        button14.setMnemonicParsing(false);
        button14.setStyle(Messages.getString("key166")); //$NON-NLS-1$
        button14.setText(Messages.getString("key167")); //$NON-NLS-1$

        GridPane.setColumnIndex(button15, 1);
        GridPane.setRowIndex(button15, 6);
        button15.setMaxWidth(100.0);
        button15.setMnemonicParsing(false);
        button15.setStyle(Messages.getString("key168")); //$NON-NLS-1$
        button15.setText(Messages.getString("key169")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox6, 1);
        GridPane.setRowIndex(comboBox6, 4);
        comboBox6.setPrefWidth(150.0);
        comboBox6.setPromptText(Messages.getString("key170")); //$NON-NLS-1$
        comboBox6.setStyle(Messages.getString("key171")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox7, 1);
        GridPane.setRowIndex(comboBox7, 5);
        comboBox7.setPrefWidth(150.0);
        comboBox7.setPromptText(Messages.getString("key172")); //$NON-NLS-1$
        comboBox7.setStyle(Messages.getString("key173")); //$NON-NLS-1$

        GridPane.setRowIndex(text1114, 4);
        text1114.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1114.setStrokeWidth(0.0);
        text1114.setText(Messages.getString("key174")); //$NON-NLS-1$

        GridPane.setRowIndex(text1115, 5);
        text1115.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1115.setStrokeWidth(0.0);
        text1115.setText(Messages.getString("key175")); //$NON-NLS-1$

        columnConstraints119.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints119.setMaxWidth(938.9019165039062);

        columnConstraints1110.setHgrow(javafx.scene.layout.Priority.ALWAYS);
        columnConstraints1110.setMinWidth(50.0);

        rowConstraints111.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints112.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints113.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints114.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints115.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints116.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints117.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        vBox8.setOpaqueInsets(new Insets(0.0));
        vBox8.setPadding(new Insets(10.0));
        vBox7.setPadding(new Insets(5.0));
        scrollPane3.setContent(vBox7);
        tab1.setContent(scrollPane3);

        tab2.setStyle(Messages.getString("key176")); //$NON-NLS-1$
        tab2.setText(Messages.getString("key177")); //$NON-NLS-1$

        scrollPane4.setFitToHeight(true);
        scrollPane4.setFitToWidth(true);
        scrollPane4.setPrefViewportHeight(1020.0);
        scrollPane4.setPrefViewportWidth(1000.0);

        vBox9.setSpacing(5.0);
        vBox9.setStyle(Messages.getString("key178")); //$NON-NLS-1$

        gridPane10.setAlignment(javafx.geometry.Pos.CENTER);

        GridPane.setHalignment(text1116, javafx.geometry.HPos.CENTER);
        text1116.setFill(javafx.scene.paint.Color.valueOf(Messages.getString("key179"))); //$NON-NLS-1$
        text1116.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1116.setStrokeWidth(0.0);
        text1116.setStyle(Messages.getString("key180")); //$NON-NLS-1$
        text1116.setText(Messages.getString("key181")); //$NON-NLS-1$
        text1116.setFont(new Font(Messages.getString("key182"), 50.0)); //$NON-NLS-1$
        GridPane.setMargin(text1116, new Insets(5.0, 0.0, 5.0, 0.0));

        columnConstraints1111.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints1111.setMinWidth(10.0);

        rowConstraints118.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        anchorPane9.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane9.setStyle(Messages.getString("key183")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox10, 0.0);
        AnchorPane.setLeftAnchor(vBox10, 0.0);
        AnchorPane.setRightAnchor(vBox10, 0.0);
        AnchorPane.setTopAnchor(vBox10, 0.0);

        text1117.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1117.setStrokeWidth(0.0);
        text1117.setStyle(Messages.getString("key184")); //$NON-NLS-1$
        text1117.setText(Messages.getString("key185")); //$NON-NLS-1$
        text1117.setFont(new Font(Messages.getString("key186"), 13.0)); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(gridPane11, 0.0);
        AnchorPane.setLeftAnchor(gridPane11, 0.0);
        AnchorPane.setRightAnchor(gridPane11, 0.0);
        AnchorPane.setTopAnchor(gridPane11, 0.0);
        gridPane11.setCacheShape(false);
        gridPane11.setCenterShape(false);
        gridPane11.setFocusTraversable(true);
        gridPane11.setHgap(10.0);
        gridPane11.setScaleShape(false);
        gridPane11.setVgap(10.0);

        text1118.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1118.setStrokeWidth(0.0);
        text1118.setText(Messages.getString("key187")); //$NON-NLS-1$

        GridPane.setColumnIndex(text1119, 2);
        GridPane.setHalignment(text1119, javafx.geometry.HPos.LEFT);
        text1119.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1119.setStrokeWidth(0.0);
        text1119.setText(Messages.getString("key188")); //$NON-NLS-1$

        GridPane.setColumnIndex(datePicker, 3);
        datePicker.setStyle(Messages.getString("key189")); //$NON-NLS-1$

        GridPane.setColumnIndex(datePicker0, 1);
        datePicker0.setStyle(Messages.getString("key190")); //$NON-NLS-1$

        columnConstraints1112.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints1112.setMaxWidth(938.9019165039062);

        columnConstraints1113.setHgrow(javafx.scene.layout.Priority.ALWAYS);
        columnConstraints1113.setMinWidth(50.0);

        columnConstraints1114.setHgrow(javafx.scene.layout.Priority.NEVER);

        columnConstraints1115.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints1115.setMaxWidth(1777.0434799194336);

        vBox10.setOpaqueInsets(new Insets(0.0));
        vBox10.setPadding(new Insets(10.0));

        anchorPane10.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane10.setStyle(Messages.getString("key191")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox11, 0.0);
        AnchorPane.setLeftAnchor(vBox11, 0.0);
        AnchorPane.setRightAnchor(vBox11, 0.0);
        AnchorPane.setTopAnchor(vBox11, 0.0);
        vBox11.setLayoutX(10.0);
        vBox11.setLayoutY(10.0);

        text11110.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11110.setStrokeWidth(0.0);
        text11110.setStyle(Messages.getString("key192")); //$NON-NLS-1$
        text11110.setText(Messages.getString("key193")); //$NON-NLS-1$
        text11110.setFont(new Font(Messages.getString("key194"), 13.0)); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(tableView3, 10.0);
        AnchorPane.setLeftAnchor(tableView3, 10.0);
        AnchorPane.setRightAnchor(tableView3, 10.0);
        AnchorPane.setTopAnchor(tableView3, 10.0);
        tableView3.setStyle(Messages.getString("key195")); //$NON-NLS-1$
        tableView3.getStylesheets().add(Messages.getString("key196")); //$NON-NLS-1$
        tableView3.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        tableColumn14.setPrefWidth(75.0);
        tableColumn14.setText(Messages.getString("key197")); //$NON-NLS-1$

        tableColumn15.setPrefWidth(75.0);
        // tableColumn15.setStyle("-fx-background-color: #553366;");
        tableColumn15.setText(Messages.getString("key198")); //$NON-NLS-1$

        tableColumn16.setPrefWidth(75.0);
        tableColumn16.setText(Messages.getString("key199")); //$NON-NLS-1$

        tableColumn17.setPrefWidth(75.0);
        tableColumn17.setText(Messages.getString("key200")); //$NON-NLS-1$
        vBox11.setPadding(new Insets(10.0));

        anchorPane11.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane11.setStyle(Messages.getString("key201")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox12, 0.0);
        AnchorPane.setLeftAnchor(vBox12, 0.0);
        AnchorPane.setRightAnchor(vBox12, 0.0);
        AnchorPane.setTopAnchor(vBox12, 0.0);

        text11111.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11111.setStrokeWidth(0.0);
        text11111.setStyle(Messages.getString("key202")); //$NON-NLS-1$
        text11111.setText(Messages.getString("key203")); //$NON-NLS-1$
        text11111.setFont(new Font(Messages.getString("key204"), 13.0)); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(gridPane12, 0.0);
        AnchorPane.setLeftAnchor(gridPane12, 0.0);
        AnchorPane.setRightAnchor(gridPane12, 0.0);
        AnchorPane.setTopAnchor(gridPane12, 0.0);
        gridPane12.setCacheShape(false);
        gridPane12.setCenterShape(false);
        gridPane12.setFocusTraversable(true);
        gridPane12.setHgap(10.0);
        gridPane12.setScaleShape(false);
        gridPane12.setVgap(10.0);

        text11112.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11112.setStrokeWidth(0.0);
        text11112.setText(Messages.getString("key205")); //$NON-NLS-1$

        GridPane.setRowIndex(text11113, 1);
        text11113.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11113.setStrokeWidth(0.0);
        text11113.setText(Messages.getString("key206")); //$NON-NLS-1$

        GridPane.setRowIndex(text11114, 2);
        text11114.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11114.setStrokeWidth(0.0);
        text11114.setText(Messages.getString("key207")); //$NON-NLS-1$

        GridPane.setRowIndex(text11115, 3);
        text11115.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11115.setStrokeWidth(0.0);
        text11115.setText(Messages.getString("key208")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField8, 1);
        GridPane.setColumnSpan(textField8, 2147483647);
        GridPane.setRowIndex(textField8, 6);
        textField8.setStyle(Messages.getString("key209")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField9, 1);
        GridPane.setColumnSpan(textField9, 2147483647);
        GridPane.setRowIndex(textField9, 4);
        textField9.setStyle(Messages.getString("key210")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField10, 1);
        GridPane.setColumnSpan(textField10, 2147483647);
        GridPane.setRowIndex(textField10, 2);
        textField10.setStyle(Messages.getString("key211")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField11, 1);
        GridPane.setColumnSpan(textField11, 2147483647);
        GridPane.setRowIndex(textField11, 3);
        textField11.setPromptText(Messages.getString("key212")); //$NON-NLS-1$
        textField11.setStyle(Messages.getString("key213")); //$NON-NLS-1$

        GridPane.setRowIndex(button16, 7);
        button16.setMaxWidth(100.0);
        button16.setMinWidth(100.0);
        button16.setMnemonicParsing(false);
        button16.setStyle(Messages.getString("key214")); //$NON-NLS-1$
        button16.setText(Messages.getString("key215")); //$NON-NLS-1$

        GridPane.setColumnIndex(button17, 1);
        GridPane.setRowIndex(button17, 7);
        button17.setMaxWidth(100.0);
        button17.setMnemonicParsing(false);
        button17.setStyle(Messages.getString("key216")); //$NON-NLS-1$
        button17.setText(Messages.getString("key217")); //$NON-NLS-1$

        GridPane.setRowIndex(text11116, 4);
        text11116.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11116.setStrokeWidth(0.0);
        text11116.setText(Messages.getString("key218")); //$NON-NLS-1$

        GridPane.setRowIndex(text11117, 5);
        text11117.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11117.setStrokeWidth(0.0);
        text11117.setText(Messages.getString("key219")); //$NON-NLS-1$

        GridPane.setRowIndex(text11118, 6);
        text11118.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11118.setStrokeWidth(0.0);
        text11118.setText(Messages.getString("key220")); //$NON-NLS-1$

        GridPane.setColumnIndex(datePicker1, 1);
        datePicker1.setStyle(Messages.getString("key221")); //$NON-NLS-1$

        GridPane.setColumnIndex(comboBox8, 1);
        GridPane.setRowIndex(comboBox8, 1);
        comboBox8.setPrefWidth(150.0);
        comboBox8.setPromptText(Messages.getString("key222")); //$NON-NLS-1$
        comboBox8.setStyle(Messages.getString("key223")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField12, 1);
        GridPane.setRowIndex(textField12, 5);
        textField12.setPromptText(Messages.getString("key224")); //$NON-NLS-1$
        textField12.setStyle(Messages.getString("key225")); //$NON-NLS-1$

        columnConstraints1116.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints1116.setMaxWidth(938.9019165039062);

        columnConstraints1117.setHgrow(javafx.scene.layout.Priority.ALWAYS);
        columnConstraints1117.setMinWidth(50.0);

        rowConstraints1110.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints1111.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints1112.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints1113.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints1114.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints1115.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints1116.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints1117.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        vBox12.setOpaqueInsets(new Insets(0.0));
        vBox12.setPadding(new Insets(10.0));
        vBox9.setPadding(new Insets(5.0));
        scrollPane4.setContent(vBox9);
        tab2.setContent(scrollPane4);

        tab3.setStyle(Messages.getString("key226")); //$NON-NLS-1$
        tab3.setText(Messages.getString("key227")); //$NON-NLS-1$

        scrollPane5.setFitToHeight(true);
        scrollPane5.setFitToWidth(true);
        scrollPane5.setPrefViewportHeight(1020.0);
        scrollPane5.setPrefViewportWidth(1000.0);

        vBox13.setSpacing(5.0);
        vBox13.setStyle(Messages.getString("key228")); //$NON-NLS-1$

        gridPane13.setAlignment(javafx.geometry.Pos.CENTER);

        GridPane.setHalignment(text11119, javafx.geometry.HPos.CENTER);
        text11119.setFill(javafx.scene.paint.Color.valueOf(Messages.getString("key229"))); //$NON-NLS-1$
        text11119.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11119.setStrokeWidth(0.0);
        text11119.setStyle(Messages.getString("key230")); //$NON-NLS-1$
        text11119.setText(Messages.getString("key231")); //$NON-NLS-1$
        text11119.setFont(new Font(Messages.getString("key232"), 50.0)); //$NON-NLS-1$
        GridPane.setMargin(text11119, new Insets(5.0, 0.0, 5.0, 0.0));

        columnConstraints1118.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints1118.setMinWidth(10.0);

        rowConstraints1118.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        anchorPane12.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane12.setStyle(Messages.getString("key233")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox14, 0.0);
        AnchorPane.setLeftAnchor(vBox14, 0.0);
        AnchorPane.setRightAnchor(vBox14, 0.0);
        AnchorPane.setTopAnchor(vBox14, 0.0);

        text111110.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111110.setStrokeWidth(0.0);
        text111110.setStyle(Messages.getString("key234")); //$NON-NLS-1$
        text111110.setText(Messages.getString("key235")); //$NON-NLS-1$
        text111110.setFont(new Font(Messages.getString("key236"), 13.0)); //$NON-NLS-1$
        VBox.setMargin(text111110, new Insets(0.0, 0.0, 10.0, 0.0));

        tableView4.setStyle(Messages.getString("key237")); //$NON-NLS-1$
        tableView4.getStylesheets().add(Messages.getString("key238")); //$NON-NLS-1$
        tableView4.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        tableColumn18.setPrefWidth(75.0);
        tableColumn18.setText(Messages.getString("key239")); //$NON-NLS-1$

        tableColumn19.setPrefWidth(75.0);
        // tableColumn19.setStyle("-fx-background-color: #553366;");
        tableColumn19.setText(Messages.getString("key240")); //$NON-NLS-1$

        tableColumn110.setPrefWidth(75.0);
        tableColumn110.setText(Messages.getString("key241")); //$NON-NLS-1$

        tableColumn111.setPrefWidth(75.0);
        tableColumn111.setText(Messages.getString("key242")); //$NON-NLS-1$

        text111111.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111111.setStrokeWidth(0.0);
        text111111.setStyle(Messages.getString("key243")); //$NON-NLS-1$
        text111111.setText(Messages.getString("key244")); //$NON-NLS-1$
        text111111.setFont(new Font(Messages.getString("key245"), 13.0)); //$NON-NLS-1$
        VBox.setMargin(text111111, new Insets(20.0, 0.0, 10.0, 0.0));

        AnchorPane.setBottomAnchor(gridPane14, 0.0);
        AnchorPane.setLeftAnchor(gridPane14, 0.0);
        AnchorPane.setRightAnchor(gridPane14, 0.0);
        AnchorPane.setTopAnchor(gridPane14, 0.0);
        gridPane14.setCacheShape(false);
        gridPane14.setCenterShape(false);
        gridPane14.setFocusTraversable(true);
        gridPane14.setHgap(10.0);
        gridPane14.setScaleShape(false);
        gridPane14.setVgap(10.0);

        text111112.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111112.setStrokeWidth(0.0);
        text111112.setText(Messages.getString("key246")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField13, 1);
        GridPane.setColumnSpan(textField13, 2147483647);
        GridPane.setRowIndex(textField13, 2);
        textField13.setStyle(Messages.getString("key247")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField14, 1);
        GridPane.setColumnSpan(textField14, 2147483647);
        textField14.setStyle(Messages.getString("key248")); //$NON-NLS-1$

        GridPane.setRowIndex(button18, 3);
        button18.setMaxWidth(100.0);
        button18.setMinWidth(100.0);
        button18.setMnemonicParsing(false);
        button18.setStyle(Messages.getString("key249")); //$NON-NLS-1$
        button18.setText(Messages.getString("key250")); //$NON-NLS-1$

        GridPane.setColumnIndex(button19, 1);
        GridPane.setRowIndex(button19, 3);
        button19.setMaxWidth(100.0);
        button19.setMnemonicParsing(false);
        button19.setStyle(Messages.getString("key251")); //$NON-NLS-1$
        button19.setText(Messages.getString("key252")); //$NON-NLS-1$

        GridPane.setRowIndex(text111113, 1);
        text111113.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111113.setStrokeWidth(0.0);
        text111113.setText(Messages.getString("key253")); //$NON-NLS-1$

        GridPane.setRowIndex(text111114, 2);
        text111114.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111114.setStrokeWidth(0.0);
        text111114.setText(Messages.getString("key254")); //$NON-NLS-1$

        GridPane.setColumnIndex(text111115, 2);
        GridPane.setRowIndex(text111115, 1);
        text111115.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111115.setStrokeWidth(0.0);
        text111115.setText(Messages.getString("key255")); //$NON-NLS-1$

        GridPane.setColumnIndex(circle, 1);
        GridPane.setRowIndex(circle, 1);
        circle.setFill(javafx.scene.paint.Color.valueOf(Messages.getString("key256"))); //$NON-NLS-1$
        circle.setRadius(50.0);
        circle.setStroke(javafx.scene.paint.Color.BLACK);
        circle.setStrokeType(javafx.scene.shape.StrokeType.INSIDE);
        circle.setStrokeWidth(0.0);

        GridPane.setColumnIndex(circle0, 3);
        GridPane.setRowIndex(circle0, 1);
        circle0.setFill(javafx.scene.paint.Color.WHITE);
        circle0.setRadius(50.0);
        circle0.setStroke(javafx.scene.paint.Color.BLACK);
        circle0.setStrokeType(javafx.scene.shape.StrokeType.INSIDE);
        circle0.setStrokeWidth(0.0);

        GridPane.setColumnIndex(text111116, 1);
        GridPane.setRowIndex(text111116, 1);
        text111116.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111116.setStrokeWidth(0.0);
        text111116.setText(Messages.getString("key257")); //$NON-NLS-1$

        GridPane.setColumnIndex(text111117, 3);
        GridPane.setRowIndex(text111117, 1);
        text111117.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111117.setStrokeWidth(0.0);
        text111117.setText(Messages.getString("key258")); //$NON-NLS-1$

        columnConstraints1119.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints1119.setMaxWidth(938.9019165039062);

        columnConstraints11110.setPrefWidth(200.0);

        columnConstraints11111.setPrefWidth(120.0);

        columnConstraints11112.setHgrow(javafx.scene.layout.Priority.ALWAYS);

        rowConstraints1119.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11110.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11111.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11112.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        vBox14.setOpaqueInsets(new Insets(0.0));
        vBox14.setPadding(new Insets(10.0));

        anchorPane13.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane13.setStyle(Messages.getString("key259")); //$NON-NLS-1$

        AnchorPane.setBottomAnchor(vBox15, 0.0);
        AnchorPane.setLeftAnchor(vBox15, 0.0);
        AnchorPane.setRightAnchor(vBox15, 0.0);
        AnchorPane.setTopAnchor(vBox15, 0.0);

        text111118.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111118.setStrokeWidth(0.0);
        text111118.setStyle(Messages.getString("key260")); //$NON-NLS-1$
        text111118.setText(Messages.getString("key261")); //$NON-NLS-1$
        text111118.setFont(new Font(Messages.getString("key262"), 13.0)); //$NON-NLS-1$
        VBox.setMargin(text111118, new Insets(0.0, 0.0, 6.0, 0.0));

        tableView5.setStyle(Messages.getString("key263")); //$NON-NLS-1$
        tableView5.getStylesheets().add(Messages.getString("key264")); //$NON-NLS-1$
        tableView5.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        tableColumn112.setPrefWidth(75.0);
        tableColumn112.setText(Messages.getString("key265")); //$NON-NLS-1$

        tableColumn113.setPrefWidth(75.0);
        // tableColumn113.setStyle("-fx-background-color: #553366;");
        tableColumn113.setText(Messages.getString("key266")); //$NON-NLS-1$

        tableColumn114.setPrefWidth(75.0);
        tableColumn114.setText(Messages.getString("key267")); //$NON-NLS-1$

        tableColumn115.setPrefWidth(75.0);
        tableColumn115.setText(Messages.getString("key268")); //$NON-NLS-1$

        text111119.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text111119.setStrokeWidth(0.0);
        text111119.setStyle(Messages.getString("key269")); //$NON-NLS-1$
        text111119.setText(Messages.getString("key270")); //$NON-NLS-1$
        text111119.setFont(new Font(Messages.getString("key271"), 13.0)); //$NON-NLS-1$
        VBox.setMargin(text111119, new Insets(20.0, 0.0, 10.0, 0.0));

        AnchorPane.setBottomAnchor(gridPane15, 0.0);
        AnchorPane.setLeftAnchor(gridPane15, 0.0);
        AnchorPane.setRightAnchor(gridPane15, 0.0);
        AnchorPane.setTopAnchor(gridPane15, 0.0);
        gridPane15.setCacheShape(false);
        gridPane15.setCenterShape(false);
        gridPane15.setFocusTraversable(true);
        gridPane15.setHgap(10.0);
        gridPane15.setScaleShape(false);
        gridPane15.setVgap(10.0);

        text1111110.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1111110.setStrokeWidth(0.0);
        text1111110.setText(Messages.getString("key272")); //$NON-NLS-1$

        GridPane.setRowIndex(text1111111, 1);
        text1111111.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1111111.setStrokeWidth(0.0);
        text1111111.setText(Messages.getString("key273")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField15, 1);
        GridPane.setColumnSpan(textField15, 2147483647);
        GridPane.setRowIndex(textField15, 2);
        textField15.setStyle(Messages.getString("key274")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField16, 1);
        GridPane.setColumnSpan(textField16, 2147483647);
        textField16.setStyle(Messages.getString("key275")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField17, 1);
        GridPane.setColumnSpan(textField17, 2147483647);
        GridPane.setRowIndex(textField17, 1);
        textField17.setPromptText(Messages.getString("key276")); //$NON-NLS-1$
        textField17.setStyle(Messages.getString("key277")); //$NON-NLS-1$

        GridPane.setRowIndex(button110, 4);
        button110.setMaxWidth(100.0);
        button110.setMinWidth(100.0);
        button110.setMnemonicParsing(false);
        button110.setStyle(Messages.getString("key278")); //$NON-NLS-1$
        button110.setText(Messages.getString("key279")); //$NON-NLS-1$

        GridPane.setColumnIndex(button111, 1);
        GridPane.setRowIndex(button111, 4);
        button111.setMaxWidth(100.0);
        button111.setMnemonicParsing(false);
        button111.setStyle(Messages.getString("key280")); //$NON-NLS-1$
        button111.setText(Messages.getString("key281")); //$NON-NLS-1$

        GridPane.setRowIndex(text1111112, 2);
        text1111112.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1111112.setStrokeWidth(0.0);
        text1111112.setText(Messages.getString("key282")); //$NON-NLS-1$

        GridPane.setRowIndex(text1111113, 3);
        text1111113.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1111113.setStrokeWidth(0.0);
        text1111113.setText(Messages.getString("key283")); //$NON-NLS-1$

        GridPane.setColumnIndex(textField18, 1);
        GridPane.setRowIndex(textField18, 3);
        textField18.setPromptText(Messages.getString("key284")); //$NON-NLS-1$
        textField18.setStyle(Messages.getString("key285")); //$NON-NLS-1$

        columnConstraints11113.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints11113.setMaxWidth(938.9019165039062);

        columnConstraints11114.setHgrow(javafx.scene.layout.Priority.ALWAYS);
        columnConstraints11114.setMinWidth(50.0);

        rowConstraints11113.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11114.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11115.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11116.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints11117.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        vBox15.setOpaqueInsets(new Insets(0.0));
        vBox15.setPadding(new Insets(10.0));
        vBox13.setPadding(new Insets(5.0));
        scrollPane5.setContent(vBox13);
        tab3.setContent(scrollPane5);

        gridPane.getColumnConstraints().add(columnConstraints);
        gridPane.getColumnConstraints().add(columnConstraints0);
        gridPane.getColumnConstraints().add(columnConstraints1);
        gridPane.getColumnConstraints().add(columnConstraints2);
        gridPane.getColumnConstraints().add(columnConstraints3);
        gridPane.getColumnConstraints().add(columnConstraints4);
        gridPane.getColumnConstraints().add(columnConstraints5);
        gridPane.getColumnConstraints().add(columnConstraints6);
        gridPane.getColumnConstraints().add(columnConstraints7);
        gridPane.getRowConstraints().add(rowConstraints);
        gridPane.getChildren().add(button);
        gridPane.getChildren().add(button0);
        gridPane.getChildren().add(button1);
        gridPane.getChildren().add(button2);
        gridPane.getChildren().add(button3);
        gridPane.getChildren().add(button4);
        gridPane.getChildren().add(button5);
        gridPane.getChildren().add(button6);
        anchorPane.getChildren().add(gridPane);
        getChildren().add(anchorPane);
        gridPane0.getChildren().add(text);
        gridPane0.getColumnConstraints().add(columnConstraints8);
        gridPane0.getRowConstraints().add(rowConstraints0);
        vBox.getChildren().add(gridPane0);
        vBox0.getChildren().add(text0);
        gridPane1.getChildren().add(text1);
        gridPane1.getChildren().add(text2);
        gridPane1.getChildren().add(text3);
        gridPane1.getChildren().add(text4);
        gridPane1.getChildren().add(text5);
        gridPane1.getChildren().add(text6);
        gridPane1.getChildren().add(text7);
        gridPane1.getChildren().add(text8);
        gridPane1.getChildren().add(textField);
        gridPane1.getChildren().add(textField0);
        gridPane1.getChildren().add(textField1);
        gridPane1.getChildren().add(comboBox);
        gridPane1.getChildren().add(comboBox0);
        gridPane1.getChildren().add(comboBox1);
        gridPane1.getChildren().add(comboBox2);
        gridPane1.getChildren().add(text9);
        gridPane1.getChildren().add(button7);
        gridPane1.getColumnConstraints().add(columnConstraints9);
        gridPane1.getColumnConstraints().add(columnConstraints10);
        gridPane1.getColumnConstraints().add(columnConstraints11);
        gridPane1.getColumnConstraints().add(columnConstraints12);
        gridPane1.getColumnConstraints().add(columnConstraints13);
        gridPane1.getRowConstraints().add(rowConstraints1);
        gridPane1.getRowConstraints().add(rowConstraints2);
        gridPane1.getRowConstraints().add(rowConstraints3);
        gridPane1.getRowConstraints().add(rowConstraints4);
        gridPane1.getRowConstraints().add(rowConstraints5);
        gridPane1.getRowConstraints().add(rowConstraints6);
        vBox0.getChildren().add(gridPane1);
        anchorPane0.getChildren().add(vBox0);
        vBox.getChildren().add(anchorPane0);
        vBox1.getChildren().add(text10);
        vBox1.getChildren().add(text11);
        gridPane2.getColumnConstraints().add(columnConstraints14);
        gridPane2.getColumnConstraints().add(columnConstraints15);
        gridPane2.getColumnConstraints().add(columnConstraints16);
        gridPane2.getRowConstraints().add(rowConstraints7);
        gridPane2.getRowConstraints().add(rowConstraints8);
        gridPane2.getChildren().add(button8);
        gridPane2.getChildren().add(text12);
        gridPane2.getChildren().add(text13);
        tableView.getColumns().add(tableColumn);
        tableView.getColumns().add(tableColumn0);
        tableView.getColumns().add(tableColumn1);
        tableView.getColumns().add(tableColumn2);
        gridPane2.getChildren().add(tableView);
        gridPane2.getChildren().add(text14);
        vBox1.getChildren().add(gridPane2);
        anchorPane1.getChildren().add(vBox1);
        vBox.getChildren().add(anchorPane1);
        vBox2.getChildren().add(text15);
        gridPane3.getChildren().add(text16);
        gridPane3.getChildren().add(button9);
        gridPane3.getChildren().add(imageView7);
        gridPane3.getChildren().add(text17);
        gridPane3.getChildren().add(text18);
        gridPane3.getChildren().add(imageView8);
        gridPane3.getChildren().add(imageView9);
        gridPane3.getChildren().add(button10);
        gridPane3.getChildren().add(button11);
        gridPane3.getChildren().add(text19);
        gridPane3.getChildren().add(comboBox3);
        gridPane3.getColumnConstraints().add(columnConstraints17);
        gridPane3.getColumnConstraints().add(columnConstraints18);
        gridPane3.getColumnConstraints().add(columnConstraints19);
        gridPane3.getRowConstraints().add(rowConstraints9);
        gridPane3.getRowConstraints().add(rowConstraints10);
        gridPane3.getRowConstraints().add(rowConstraints11);
        gridPane3.getRowConstraints().add(rowConstraints12);
        vBox2.getChildren().add(gridPane3);
        vBox2.getChildren().add(text110);
        anchorPane2.getChildren().add(vBox2);
        vBox.getChildren().add(anchorPane2);
        tabPane.getTabs().add(tab);
        gridPane4.getChildren().add(text111);
        gridPane4.getColumnConstraints().add(columnConstraints110);
        gridPane4.getRowConstraints().add(rowConstraints13);
        vBox3.getChildren().add(gridPane4);
        tableView0.getColumns().add(tableColumn3);
        tableView0.getColumns().add(tableColumn4);
        tableView0.getColumns().add(tableColumn5);
        vBox4.getChildren().add(tableView0);
        vBox4.getChildren().add(text112);
        gridPane5.getChildren().add(text113);
        gridPane5.getChildren().add(textField2);
        gridPane5.getChildren().add(textField3);
        gridPane5.getChildren().add(button12);
        gridPane5.getChildren().add(button13);
        gridPane5.getChildren().add(text114);
        gridPane5.getColumnConstraints().add(columnConstraints111);
        gridPane5.getColumnConstraints().add(columnConstraints112);
        gridPane5.getColumnConstraints().add(columnConstraints113);
        gridPane5.getColumnConstraints().add(columnConstraints114);
        gridPane5.getRowConstraints().add(rowConstraints14);
        gridPane5.getRowConstraints().add(rowConstraints15);
        gridPane5.getRowConstraints().add(rowConstraints16);
        vBox4.getChildren().add(gridPane5);
        anchorPane4.getChildren().add(vBox4);
        vBox3.getChildren().add(anchorPane4);
        anchorPane3.getChildren().add(scrollPane1);
        splitPane.getItems().add(anchorPane3);
        gridPane6.getChildren().add(text115);
        gridPane6.getColumnConstraints().add(columnConstraints115);
        gridPane6.getRowConstraints().add(rowConstraints17);
        vBox5.getChildren().add(gridPane6);
        tableView1.getColumns().add(tableColumn6);
        tableView1.getColumns().add(tableColumn7);
        tableView1.getColumns().add(tableColumn8);
        vBox6.getChildren().add(tableView1);
        gridPane7.getChildren().add(text116);
        gridPane7.getChildren().add(text117);
        gridPane7.getChildren().add(comboBox4);
        gridPane7.getChildren().add(comboBox5);
        gridPane7.getColumnConstraints().add(columnConstraints116);
        gridPane7.getColumnConstraints().add(columnConstraints117);
        gridPane7.getRowConstraints().add(rowConstraints18);
        gridPane7.getRowConstraints().add(rowConstraints19);
        vBox6.getChildren().add(gridPane7);
        anchorPane6.getChildren().add(vBox6);
        vBox5.getChildren().add(anchorPane6);
        anchorPane5.getChildren().add(scrollPane2);
        splitPane.getItems().add(anchorPane5);
        tabPane.getTabs().add(tab0);
        gridPane8.getColumnConstraints().add(columnConstraints118);
        gridPane8.getRowConstraints().add(rowConstraints110);
        gridPane8.getChildren().add(text118);
        vBox7.getChildren().add(gridPane8);
        tableView2.getColumns().add(tableColumn9);
        tableView2.getColumns().add(tableColumn10);
        tableView2.getColumns().add(tableColumn11);
        tableView2.getColumns().add(tableColumn12);
        tableView2.getColumns().add(tableColumn13);
        anchorPane7.getChildren().add(tableView2);
        vBox7.getChildren().add(anchorPane7);
        vBox8.getChildren().add(text119);
        gridPane9.getChildren().add(text1110);
        gridPane9.getChildren().add(text1111);
        gridPane9.getChildren().add(text1112);
        gridPane9.getChildren().add(text1113);
        gridPane9.getChildren().add(textField4);
        gridPane9.getChildren().add(textField5);
        gridPane9.getChildren().add(textField6);
        gridPane9.getChildren().add(textField7);
        gridPane9.getChildren().add(button14);
        gridPane9.getChildren().add(button15);
        gridPane9.getChildren().add(comboBox6);
        gridPane9.getChildren().add(comboBox7);
        gridPane9.getChildren().add(text1114);
        gridPane9.getChildren().add(text1115);
        gridPane9.getColumnConstraints().add(columnConstraints119);
        gridPane9.getColumnConstraints().add(columnConstraints1110);
        gridPane9.getRowConstraints().add(rowConstraints111);
        gridPane9.getRowConstraints().add(rowConstraints112);
        gridPane9.getRowConstraints().add(rowConstraints113);
        gridPane9.getRowConstraints().add(rowConstraints114);
        gridPane9.getRowConstraints().add(rowConstraints115);
        gridPane9.getRowConstraints().add(rowConstraints116);
        gridPane9.getRowConstraints().add(rowConstraints117);
        vBox8.getChildren().add(gridPane9);
        anchorPane8.getChildren().add(vBox8);
        vBox7.getChildren().add(anchorPane8);
        tabPane.getTabs().add(tab1);
        gridPane10.getChildren().add(text1116);
        gridPane10.getColumnConstraints().add(columnConstraints1111);
        gridPane10.getRowConstraints().add(rowConstraints118);
        vBox9.getChildren().add(gridPane10);
        vBox10.getChildren().add(text1117);
        gridPane11.getChildren().add(text1118);
        gridPane11.getChildren().add(text1119);
        gridPane11.getChildren().add(datePicker);
        gridPane11.getChildren().add(datePicker0);
        gridPane11.getColumnConstraints().add(columnConstraints1112);
        gridPane11.getColumnConstraints().add(columnConstraints1113);
        gridPane11.getColumnConstraints().add(columnConstraints1114);
        gridPane11.getColumnConstraints().add(columnConstraints1115);
        gridPane11.getRowConstraints().add(rowConstraints119);
        vBox10.getChildren().add(gridPane11);
        anchorPane9.getChildren().add(vBox10);
        vBox9.getChildren().add(anchorPane9);
        vBox11.getChildren().add(text11110);
        tableView3.getColumns().add(tableColumn14);
        tableView3.getColumns().add(tableColumn15);
        tableView3.getColumns().add(tableColumn16);
        tableView3.getColumns().add(tableColumn17);
        vBox11.getChildren().add(tableView3);
        anchorPane10.getChildren().add(vBox11);
        vBox9.getChildren().add(anchorPane10);
        vBox12.getChildren().add(text11111);
        gridPane12.getChildren().add(text11112);
        gridPane12.getChildren().add(text11113);
        gridPane12.getChildren().add(text11114);
        gridPane12.getChildren().add(text11115);
        gridPane12.getChildren().add(textField8);
        gridPane12.getChildren().add(textField9);
        gridPane12.getChildren().add(textField10);
        gridPane12.getChildren().add(textField11);
        gridPane12.getChildren().add(button16);
        gridPane12.getChildren().add(button17);
        gridPane12.getChildren().add(text11116);
        gridPane12.getChildren().add(text11117);
        gridPane12.getChildren().add(text11118);
        gridPane12.getChildren().add(datePicker1);
        gridPane12.getChildren().add(comboBox8);
        gridPane12.getChildren().add(textField12);
        gridPane12.getColumnConstraints().add(columnConstraints1116);
        gridPane12.getColumnConstraints().add(columnConstraints1117);
        gridPane12.getRowConstraints().add(rowConstraints1110);
        gridPane12.getRowConstraints().add(rowConstraints1111);
        gridPane12.getRowConstraints().add(rowConstraints1112);
        gridPane12.getRowConstraints().add(rowConstraints1113);
        gridPane12.getRowConstraints().add(rowConstraints1114);
        gridPane12.getRowConstraints().add(rowConstraints1115);
        gridPane12.getRowConstraints().add(rowConstraints1116);
        gridPane12.getRowConstraints().add(rowConstraints1117);
        vBox12.getChildren().add(gridPane12);
        anchorPane11.getChildren().add(vBox12);
        vBox9.getChildren().add(anchorPane11);
        tabPane.getTabs().add(tab2);
        gridPane13.getChildren().add(text11119);
        gridPane13.getColumnConstraints().add(columnConstraints1118);
        gridPane13.getRowConstraints().add(rowConstraints1118);
        vBox13.getChildren().add(gridPane13);
        vBox14.getChildren().add(text111110);
        tableView4.getColumns().add(tableColumn18);
        tableView4.getColumns().add(tableColumn19);
        tableView4.getColumns().add(tableColumn110);
        tableView4.getColumns().add(tableColumn111);
        vBox14.getChildren().add(tableView4);
        vBox14.getChildren().add(text111111);
        gridPane14.getChildren().add(text111112);
        gridPane14.getChildren().add(textField13);
        gridPane14.getChildren().add(textField14);
        gridPane14.getChildren().add(button18);
        gridPane14.getChildren().add(button19);
        gridPane14.getChildren().add(text111113);
        gridPane14.getChildren().add(text111114);
        gridPane14.getChildren().add(text111115);
        gridPane14.getChildren().add(circle);
        gridPane14.getChildren().add(circle0);
        gridPane14.getChildren().add(text111116);
        gridPane14.getChildren().add(text111117);
        gridPane14.getColumnConstraints().add(columnConstraints1119);
        gridPane14.getColumnConstraints().add(columnConstraints11110);
        gridPane14.getColumnConstraints().add(columnConstraints11111);
        gridPane14.getColumnConstraints().add(columnConstraints11112);
        gridPane14.getRowConstraints().add(rowConstraints1119);
        gridPane14.getRowConstraints().add(rowConstraints11110);
        gridPane14.getRowConstraints().add(rowConstraints11111);
        gridPane14.getRowConstraints().add(rowConstraints11112);
        vBox14.getChildren().add(gridPane14);
        anchorPane12.getChildren().add(vBox14);
        vBox13.getChildren().add(anchorPane12);
        vBox15.getChildren().add(text111118);
        tableView5.getColumns().add(tableColumn112);
        tableView5.getColumns().add(tableColumn113);
        tableView5.getColumns().add(tableColumn114);
        tableView5.getColumns().add(tableColumn115);
        vBox15.getChildren().add(tableView5);
        vBox15.getChildren().add(text111119);
        gridPane15.getChildren().add(text1111110);
        gridPane15.getChildren().add(text1111111);
        gridPane15.getChildren().add(textField15);
        gridPane15.getChildren().add(textField16);
        gridPane15.getChildren().add(textField17);
        gridPane15.getChildren().add(button110);
        gridPane15.getChildren().add(button111);
        gridPane15.getChildren().add(text1111112);
        gridPane15.getChildren().add(text1111113);
        gridPane15.getChildren().add(textField18);
        gridPane15.getColumnConstraints().add(columnConstraints11113);
        gridPane15.getColumnConstraints().add(columnConstraints11114);
        gridPane15.getRowConstraints().add(rowConstraints11113);
        gridPane15.getRowConstraints().add(rowConstraints11114);
        gridPane15.getRowConstraints().add(rowConstraints11115);
        gridPane15.getRowConstraints().add(rowConstraints11116);
        gridPane15.getRowConstraints().add(rowConstraints11117);
        vBox15.getChildren().add(gridPane15);
        anchorPane13.getChildren().add(vBox15);
        vBox13.getChildren().add(anchorPane13);
        tabPane.getTabs().add(tab3);
        getChildren().add(tabPane);

    }
}
