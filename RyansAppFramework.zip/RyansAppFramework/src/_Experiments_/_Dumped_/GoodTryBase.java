package _Experiments_._Dumped_;

import _Externals_._Resources_.ResourceGetter;
import javafx.scene.image.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import javafx.scene.control.*;
import java.lang.*;
import javafx.scene.layout.*;

public class GoodTryBase extends VBox {

    protected final AnchorPane anchorPane;
    protected final GridPane gridPane;
    protected final ColumnConstraints columnConstraints;
    protected final ColumnConstraints columnConstraints0;
    protected final ColumnConstraints columnConstraints1;
    protected final ColumnConstraints columnConstraints2;
    protected final ColumnConstraints columnConstraints3;
    protected final ColumnConstraints columnConstraints4;
    protected final ColumnConstraints columnConstraints5;
    protected final ColumnConstraints columnConstraints6;
    protected final ColumnConstraints columnConstraints7;
    protected final RowConstraints rowConstraints;
    protected final Button button;
    protected final Button button0;
    protected final Button button1;
    protected final Button button2;
    protected final Button button3;
    protected final Button button4;
    protected final Button button5;
    protected final Button button6;
    protected final TabPane tabPane;
    protected final Tab tab;
    protected final ScrollPane scrollPane;
    protected final VBox vBox;
    protected final AnchorPane anchorPane0;
    protected final VBox vBox0;
    protected final Text text;
    protected final GridPane gridPane0;
    protected final Text text0;
    protected final Text text1;
    protected final Text text2;
    protected final Text text3;
    protected final Text text4;
    protected final Text text5;
    protected final Text text6;
    protected final Text text7;
    protected final TextField textField;
    protected final TextField textField0;
    protected final TextField textField1;
    protected final ComboBox comboBox;
    protected final ComboBox comboBox0;
    protected final ComboBox comboBox1;
    protected final ComboBox comboBox2;
    protected final Text text8;
    protected final Button button7;
    protected final ColumnConstraints columnConstraints8;
    protected final ColumnConstraints columnConstraints9;
    protected final ColumnConstraints columnConstraints10;
    protected final ColumnConstraints columnConstraints11;
    protected final ColumnConstraints columnConstraints12;
    protected final RowConstraints rowConstraints0;
    protected final RowConstraints rowConstraints1;
    protected final RowConstraints rowConstraints2;
    protected final RowConstraints rowConstraints3;
    protected final RowConstraints rowConstraints4;
    protected final RowConstraints rowConstraints5;
    protected final AnchorPane anchorPane1;
    protected final VBox vBox1;
    protected final Text text9;
    protected final GridPane gridPane1;
    protected final ColumnConstraints columnConstraints13;
    protected final ColumnConstraints columnConstraints14;
    protected final ColumnConstraints columnConstraints15;
    protected final RowConstraints rowConstraints6;
    protected final Button button8;
    protected final Text text10;
    protected final Text text11;
    protected final TableView tableView;
    protected final TableColumn tableColumn;
    protected final TableColumn tableColumn0;
    protected final AnchorPane anchorPane2;
    protected final VBox vBox2;
    protected final GridPane gridPane2;
    protected final Text text12;
    protected final Button button9;
    protected final ImageView imageView;
    protected final ColumnConstraints columnConstraints16;
    protected final ColumnConstraints columnConstraints17;
    protected final ColumnConstraints columnConstraints18;
    protected final RowConstraints rowConstraints7;
    protected final GridPane gridPane3;
    protected final Text text13;
    protected final Button button10;
    protected final ImageView imageView0;
    protected final ColumnConstraints columnConstraints19;
    protected final ColumnConstraints columnConstraints110;
    protected final ColumnConstraints columnConstraints111;
    protected final RowConstraints rowConstraints8;
    protected final GridPane gridPane4;
    protected final Text text14;
    protected final Button button11;
    protected final ImageView imageView1;
    protected final ColumnConstraints columnConstraints112;
    protected final ColumnConstraints columnConstraints113;
    protected final ColumnConstraints columnConstraints114;
    protected final RowConstraints rowConstraints9;

    public GoodTryBase() {

        anchorPane = new AnchorPane();
        gridPane = new GridPane();
        columnConstraints = new ColumnConstraints();
        columnConstraints0 = new ColumnConstraints();
        columnConstraints1 = new ColumnConstraints();
        columnConstraints2 = new ColumnConstraints();
        columnConstraints3 = new ColumnConstraints();
        columnConstraints4 = new ColumnConstraints();
        columnConstraints5 = new ColumnConstraints();
        columnConstraints6 = new ColumnConstraints();
        columnConstraints7 = new ColumnConstraints();
        rowConstraints = new RowConstraints();
        button = new Button();
        button0 = new Button();
        button1 = new Button();
        button2 = new Button();
        button3 = new Button();
        button4 = new Button();
        button5 = new Button();
        button6 = new Button();
        tabPane = new TabPane();
        tab = new Tab();
        scrollPane = new ScrollPane();
        vBox = new VBox();
        anchorPane0 = new AnchorPane();
        vBox0 = new VBox();
        text = new Text();
        gridPane0 = new GridPane();
        text0 = new Text();
        text1 = new Text();
        text2 = new Text();
        text3 = new Text();
        text4 = new Text();
        text5 = new Text();
        text6 = new Text();
        text7 = new Text();
        textField = new TextField();
        textField0 = new TextField();
        textField1 = new TextField();
        comboBox = new ComboBox();
        comboBox0 = new ComboBox();
        comboBox1 = new ComboBox();
        comboBox2 = new ComboBox();
        text8 = new Text();
        button7 = new Button();
        columnConstraints8 = new ColumnConstraints();
        columnConstraints9 = new ColumnConstraints();
        columnConstraints10 = new ColumnConstraints();
        columnConstraints11 = new ColumnConstraints();
        columnConstraints12 = new ColumnConstraints();
        rowConstraints0 = new RowConstraints();
        rowConstraints1 = new RowConstraints();
        rowConstraints2 = new RowConstraints();
        rowConstraints3 = new RowConstraints();
        rowConstraints4 = new RowConstraints();
        rowConstraints5 = new RowConstraints();
        anchorPane1 = new AnchorPane();
        vBox1 = new VBox();
        text9 = new Text();
        gridPane1 = new GridPane();
        columnConstraints13 = new ColumnConstraints();
        columnConstraints14 = new ColumnConstraints();
        columnConstraints15 = new ColumnConstraints();
        rowConstraints6 = new RowConstraints();
        button8 = new Button();
        text10 = new Text();
        text11 = new Text();
        tableView = new TableView();
        tableColumn = new TableColumn();
        tableColumn0 = new TableColumn();
        anchorPane2 = new AnchorPane();
        vBox2 = new VBox();
        gridPane2 = new GridPane();
        text12 = new Text();
        button9 = new Button();
        imageView = new ImageView();
        columnConstraints16 = new ColumnConstraints();
        columnConstraints17 = new ColumnConstraints();
        columnConstraints18 = new ColumnConstraints();
        rowConstraints7 = new RowConstraints();
        gridPane3 = new GridPane();
        text13 = new Text();
        button10 = new Button();
        imageView0 = new ImageView();
        columnConstraints19 = new ColumnConstraints();
        columnConstraints110 = new ColumnConstraints();
        columnConstraints111 = new ColumnConstraints();
        rowConstraints8 = new RowConstraints();
        gridPane4 = new GridPane();
        text14 = new Text();
        button11 = new Button();
        imageView1 = new ImageView();
        columnConstraints112 = new ColumnConstraints();
        columnConstraints113 = new ColumnConstraints();
        columnConstraints114 = new ColumnConstraints();
        rowConstraints9 = new RowConstraints();

        setMaxHeight(USE_PREF_SIZE);
        setMaxWidth(USE_PREF_SIZE);
        setMinHeight(USE_PREF_SIZE);
        setMinWidth(USE_PREF_SIZE);
        setPrefHeight(1080.0);
        setPrefWidth(1000.0);
        setStyle("-fx-background-color: #555555;");

        AnchorPane.setLeftAnchor(gridPane, 0.0);
        AnchorPane.setRightAnchor(gridPane, 0.0);
        gridPane.setStyle("-fx-background-color: #775566;");

        columnConstraints.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints0.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints1.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints2.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints3.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints4.setHgrow(javafx.scene.layout.Priority.ALWAYS);

        columnConstraints5.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints6.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints7.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints.setMinHeight(10.0);
        rowConstraints.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        button.setMnemonicParsing(false);
        button.setText("New");

        GridPane.setColumnIndex(button0, 1);
        button0.setMnemonicParsing(false);
        button0.setText("Load");

        GridPane.setColumnIndex(button1, 2);
        button1.setMnemonicParsing(false);
        button1.setText("Save");

        GridPane.setColumnIndex(button2, 3);
        button2.setMnemonicParsing(false);
        button2.setText("Save As");

        GridPane.setColumnIndex(button3, 4);
        button3.setMnemonicParsing(false);
        button3.setText("Export");

        GridPane.setColumnIndex(button4, 6);
        GridPane.setHalignment(button4, javafx.geometry.HPos.RIGHT);
        button4.setMnemonicParsing(false);
        button4.setText("Undo");

        GridPane.setColumnIndex(button5, 7);
        GridPane.setHalignment(button5, javafx.geometry.HPos.RIGHT);
        button5.setMnemonicParsing(false);
        button5.setText("Redo");

        GridPane.setColumnIndex(button6, 8);
        GridPane.setHalignment(button6, javafx.geometry.HPos.RIGHT);
        button6.setMnemonicParsing(false);
        button6.setText("About");

        VBox.setVgrow(tabPane, javafx.scene.layout.Priority.ALWAYS);
        tabPane.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        tabPane.setOpacity(0.93);
        tabPane.setPrefHeight(200.0);
        tabPane.setPrefWidth(200.0);
        tabPane.getStylesheets().add("/_Experiments_/_Dumped_/appstyle.css");
        tabPane.setTabClosingPolicy(javafx.scene.control.TabPane.TabClosingPolicy.UNAVAILABLE);

        tab.setStyle("-fx-background-color: #99BBFF;");
        tab.setText("Course Details");

        scrollPane.setFitToHeight(true);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefViewportHeight(1020.0);
        scrollPane.setPrefViewportWidth(1000.0);

        vBox.setSpacing(5.0);
        vBox.setStyle("-fx-background-color: #336688; -fx-background-radius: 0;");

        anchorPane0.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane0.setPrefHeight(180.0);
        anchorPane0.setPrefWidth(200.0);
        anchorPane0.setStyle("-fx-background-color: #8888FF;");

        AnchorPane.setBottomAnchor(vBox0, 0.0);
        AnchorPane.setLeftAnchor(vBox0, 0.0);
        AnchorPane.setRightAnchor(vBox0, 0.0);
        AnchorPane.setTopAnchor(vBox0, 0.0);

        text.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text.setStrokeWidth(0.0);
        text.setText("Text");

        AnchorPane.setBottomAnchor(gridPane0, 0.0);
        AnchorPane.setLeftAnchor(gridPane0, 0.0);
        AnchorPane.setRightAnchor(gridPane0, 0.0);
        AnchorPane.setTopAnchor(gridPane0, 0.0);
        gridPane0.setCacheShape(false);
        gridPane0.setCenterShape(false);
        gridPane0.setFocusTraversable(true);
        gridPane0.setScaleShape(false);

        text0.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text0.setStrokeWidth(0.0);
        text0.setText("Subject:");

        GridPane.setRowIndex(text1, 1);
        text1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text1.setStrokeWidth(0.0);
        text1.setText("Semester:");

        GridPane.setColumnIndex(text2, 3);
        GridPane.setHalignment(text2, javafx.geometry.HPos.LEFT);
        text2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text2.setStrokeWidth(0.0);
        text2.setText("Number:");

        GridPane.setColumnIndex(text3, 3);
        GridPane.setHalignment(text3, javafx.geometry.HPos.LEFT);
        GridPane.setRowIndex(text3, 1);
        text3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text3.setStrokeWidth(0.0);
        text3.setText("Year:");

        GridPane.setRowIndex(text4, 2);
        text4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text4.setStrokeWidth(0.0);
        text4.setText("Title:");

        GridPane.setRowIndex(text5, 3);
        text5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text5.setStrokeWidth(0.0);
        text5.setText("Instructor Name:");

        GridPane.setRowIndex(text6, 4);
        text6.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text6.setStrokeWidth(0.0);
        text6.setText("Instructor Home:");

        GridPane.setRowIndex(text7, 5);
        text7.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text7.setStrokeWidth(0.0);
        text7.setText("Export Dir:");

        GridPane.setColumnIndex(textField, 1);
        GridPane.setColumnSpan(textField, 2147483647);
        GridPane.setRowIndex(textField, 2);
        textField.setPromptText("Computer Science III");

        GridPane.setColumnIndex(textField0, 1);
        GridPane.setColumnSpan(textField0, 2147483647);
        GridPane.setRowIndex(textField0, 3);
        textField0.setPromptText("Richard McKenna");

        GridPane.setColumnIndex(textField1, 1);
        GridPane.setColumnSpan(textField1, 2147483647);
        GridPane.setRowIndex(textField1, 4);
        textField1.setPromptText("http://www3.cs.stonybrook.edu/~cse219/Section02/index.html");

        GridPane.setColumnIndex(comboBox, 1);
        comboBox.setPrefWidth(150.0);
        comboBox.setPromptText("CSE");

        GridPane.setColumnIndex(comboBox0, 1);
        GridPane.setRowIndex(comboBox0, 1);
        comboBox0.setPrefWidth(150.0);
        comboBox0.setPromptText("Fall");

        GridPane.setColumnIndex(comboBox1, 4);
        GridPane.setHalignment(comboBox1, javafx.geometry.HPos.RIGHT);
        comboBox1.setPrefWidth(150.0);
        comboBox1.setPromptText("219");

        GridPane.setColumnIndex(comboBox2, 4);
        GridPane.setHalignment(comboBox2, javafx.geometry.HPos.RIGHT);
        GridPane.setRowIndex(comboBox2, 1);
        comboBox2.setPrefWidth(150.0);
        comboBox2.setPromptText("2017");

        GridPane.setColumnIndex(text8, 1);
        GridPane.setColumnSpan(text8, 2);
        GridPane.setHalignment(text8, javafx.geometry.HPos.LEFT);
        GridPane.setRowIndex(text8, 5);
        text8.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text8.setStrokeWidth(0.0);
        text8.setText("aodsjaosidjaoisjdoaisdjoiasjdoiasjdoaijsdoiasjdoiasjdoasjdoasidjaoijdoiajd");

        GridPane.setColumnIndex(button7, 4);
        GridPane.setHalignment(button7, javafx.geometry.HPos.RIGHT);
        GridPane.setRowIndex(button7, 5);
        button7.setMnemonicParsing(false);
        button7.setText("Change");

        columnConstraints8.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints8.setMaxWidth(938.9019165039062);

        columnConstraints9.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints10.setHgrow(javafx.scene.layout.Priority.ALWAYS);
        columnConstraints10.setMinWidth(0.0);

        columnConstraints11.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints12.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints12.setMaxWidth(1777.0434799194336);

        rowConstraints1.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints2.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints3.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints4.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        rowConstraints5.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        anchorPane1.setMinHeight(0.0);
        anchorPane1.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane1.setPrefHeight(180.0);
        anchorPane1.setPrefWidth(200.0);
        anchorPane1.setStyle("-fx-background-color: #8888FF;");

        AnchorPane.setBottomAnchor(vBox1, 0.0);
        AnchorPane.setLeftAnchor(vBox1, 0.0);
        AnchorPane.setRightAnchor(vBox1, 0.0);
        AnchorPane.setTopAnchor(vBox1, 0.0);
        vBox1.setPrefHeight(180.0);
        vBox1.setPrefWidth(1918.0);

        text9.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text9.setStrokeWidth(0.0);
        text9.setText("The selected directory should contain the full site template, including the HTML files ");

        columnConstraints13.setHgrow(javafx.scene.layout.Priority.SOMETIMES);

        columnConstraints14.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints14.setMinWidth(10.0);
        columnConstraints14.setPrefWidth(100.0);

        columnConstraints15.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints15.setPrefWidth(100.0);

        GridPane.setColumnIndex(button8, 2);
        GridPane.setHalignment(button8, javafx.geometry.HPos.RIGHT);
        button8.setMnemonicParsing(false);
        button8.setText("Change");

        GridPane.setColumnIndex(text10, 1);
        text10.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text10.setStrokeWidth(0.0);
        text10.setText(".\\templates\\CSE219");

        text11.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text11.setStrokeWidth(0.0);
        text11.setText("Template Dir:");

        tableColumn.setPrefWidth(75.0);
        tableColumn.setText("C1");

        tableColumn0.setPrefWidth(75.0);
        tableColumn0.setText("C2");

        anchorPane2.setMinHeight(0.0);
        anchorPane2.setNodeOrientation(javafx.geometry.NodeOrientation.LEFT_TO_RIGHT);
        anchorPane2.setPrefHeight(180.0);
        anchorPane2.setPrefWidth(200.0);
        anchorPane2.setStyle("-fx-background-color: #8888FF;");

        AnchorPane.setBottomAnchor(vBox2, 0.0);
        AnchorPane.setLeftAnchor(vBox2, 0.0);
        AnchorPane.setRightAnchor(vBox2, 0.0);
        AnchorPane.setTopAnchor(vBox2, 0.0);
        vBox2.setPrefHeight(180.0);
        vBox2.setPrefWidth(998.0);

        gridPane2.setCacheShape(false);
        gridPane2.setCenterShape(false);
        gridPane2.setFocusTraversable(true);
        gridPane2.setHgap(20.0);
        gridPane2.setPrefWidth(998.0);
        gridPane2.setScaleShape(false);
        gridPane2.setVgap(20.0);

        text12.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text12.setStrokeWidth(0.0);
        text12.setText("Banner School Image:");

        GridPane.setColumnIndex(button9, 2);
        GridPane.setHalignment(button9, javafx.geometry.HPos.RIGHT);
        button9.setMnemonicParsing(false);
        button9.setText("Change");

        GridPane.setColumnIndex(imageView, 1);
        GridPane.setHalignment(imageView, javafx.geometry.HPos.CENTER);
        imageView.setFitHeight(150.0);
        imageView.setFitWidth(200.0);
        imageView.setPickOnBounds(true);
        imageView.setPreserveRatio(true);
        imageView.setImage(ResourceGetter.getImage("bannerimmage.png"));

        columnConstraints16.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints16.setMaxWidth(200.0);
        columnConstraints16.setPrefWidth(200.0);

        columnConstraints17.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints17.setMaxWidth(1777.0434799194336);

        columnConstraints18.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints18.setMaxWidth(Double.MAX_VALUE);
        columnConstraints18.setPrefWidth(200.0);

        rowConstraints7.setMinHeight(10.0);
        rowConstraints7.setPrefHeight(30.0);
        rowConstraints7.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        gridPane3.setCacheShape(false);
        gridPane3.setCenterShape(false);
        gridPane3.setFocusTraversable(true);
        gridPane3.setHgap(20.0);
        gridPane3.setPrefWidth(998.0);
        gridPane3.setScaleShape(false);
        gridPane3.setVgap(20.0);

        text13.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text13.setStrokeWidth(0.0);
        text13.setText("Left Footer Image:");

        GridPane.setColumnIndex(button10, 2);
        GridPane.setHalignment(button10, javafx.geometry.HPos.RIGHT);
        button10.setMnemonicParsing(false);
        button10.setText("Change");

        GridPane.setColumnIndex(imageView0, 1);
        GridPane.setHalignment(imageView0, javafx.geometry.HPos.CENTER);
        imageView0.setFitHeight(150.0);
        imageView0.setFitWidth(200.0);
        imageView0.setPickOnBounds(true);
        imageView0.setPreserveRatio(true);
        imageView0.setImage(ResourceGetter.getImage("bannerimmage.png"));

        columnConstraints19.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints19.setMaxWidth(200.0);
        columnConstraints19.setPrefWidth(200.0);

        columnConstraints110.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints110.setMaxWidth(1777.0434799194336);

        columnConstraints111.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints111.setMaxWidth(Double.MAX_VALUE);
        columnConstraints111.setPrefWidth(200.0);

        rowConstraints8.setMinHeight(10.0);
        rowConstraints8.setPrefHeight(30.0);
        rowConstraints8.setVgrow(javafx.scene.layout.Priority.SOMETIMES);

        gridPane4.setCacheShape(false);
        gridPane4.setCenterShape(false);
        gridPane4.setFocusTraversable(true);
        gridPane4.setHgap(20.0);
        gridPane4.setPrefWidth(998.0);
        gridPane4.setScaleShape(false);
        gridPane4.setVgap(20.0);

        text14.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        text14.setStrokeWidth(0.0);
        text14.setText("Right Footer Image:");

        GridPane.setColumnIndex(button11, 2);
        GridPane.setHalignment(button11, javafx.geometry.HPos.RIGHT);
        button11.setMnemonicParsing(false);
        button11.setText("Change");

        GridPane.setColumnIndex(imageView1, 1);
        GridPane.setHalignment(imageView1, javafx.geometry.HPos.CENTER);
        imageView1.setFitHeight(150.0);
        imageView1.setFitWidth(200.0);
        imageView1.setPickOnBounds(true);
        imageView1.setPreserveRatio(true);
        imageView1.setImage(ResourceGetter.getImage("bannerimmage.png"));

        columnConstraints112.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints112.setMaxWidth(200.0);
        columnConstraints112.setPrefWidth(200.0);

        columnConstraints113.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints113.setMaxWidth(1777.0434799194336);

        columnConstraints114.setHgrow(javafx.scene.layout.Priority.SOMETIMES);
        columnConstraints114.setMaxWidth(Double.MAX_VALUE);
        columnConstraints114.setPrefWidth(200.0);

        rowConstraints9.setMinHeight(10.0);
        rowConstraints9.setPrefHeight(30.0);
        rowConstraints9.setVgrow(javafx.scene.layout.Priority.SOMETIMES);
        vBox.setPadding(new Insets(5.0, 5.0, 0.0, 5.0));
        scrollPane.setContent(vBox);
        tab.setContent(scrollPane);

        gridPane.getColumnConstraints().add(columnConstraints);
        gridPane.getColumnConstraints().add(columnConstraints0);
        gridPane.getColumnConstraints().add(columnConstraints1);
        gridPane.getColumnConstraints().add(columnConstraints2);
        gridPane.getColumnConstraints().add(columnConstraints3);
        gridPane.getColumnConstraints().add(columnConstraints4);
        gridPane.getColumnConstraints().add(columnConstraints5);
        gridPane.getColumnConstraints().add(columnConstraints6);
        gridPane.getColumnConstraints().add(columnConstraints7);
        gridPane.getRowConstraints().add(rowConstraints);
        gridPane.getChildren().add(button);
        gridPane.getChildren().add(button0);
        gridPane.getChildren().add(button1);
        gridPane.getChildren().add(button2);
        gridPane.getChildren().add(button3);
        gridPane.getChildren().add(button4);
        gridPane.getChildren().add(button5);
        gridPane.getChildren().add(button6);
        anchorPane.getChildren().add(gridPane);
        getChildren().add(anchorPane);
        vBox0.getChildren().add(text);
        gridPane0.getChildren().add(text0);
        gridPane0.getChildren().add(text1);
        gridPane0.getChildren().add(text2);
        gridPane0.getChildren().add(text3);
        gridPane0.getChildren().add(text4);
        gridPane0.getChildren().add(text5);
        gridPane0.getChildren().add(text6);
        gridPane0.getChildren().add(text7);
        gridPane0.getChildren().add(textField);
        gridPane0.getChildren().add(textField0);
        gridPane0.getChildren().add(textField1);
        gridPane0.getChildren().add(comboBox);
        gridPane0.getChildren().add(comboBox0);
        gridPane0.getChildren().add(comboBox1);
        gridPane0.getChildren().add(comboBox2);
        gridPane0.getChildren().add(text8);
        gridPane0.getChildren().add(button7);
        gridPane0.getColumnConstraints().add(columnConstraints8);
        gridPane0.getColumnConstraints().add(columnConstraints9);
        gridPane0.getColumnConstraints().add(columnConstraints10);
        gridPane0.getColumnConstraints().add(columnConstraints11);
        gridPane0.getColumnConstraints().add(columnConstraints12);
        gridPane0.getRowConstraints().add(rowConstraints0);
        gridPane0.getRowConstraints().add(rowConstraints1);
        gridPane0.getRowConstraints().add(rowConstraints2);
        gridPane0.getRowConstraints().add(rowConstraints3);
        gridPane0.getRowConstraints().add(rowConstraints4);
        gridPane0.getRowConstraints().add(rowConstraints5);
        vBox0.getChildren().add(gridPane0);
        anchorPane0.getChildren().add(vBox0);
        vBox.getChildren().add(anchorPane0);
        vBox1.getChildren().add(text9);
        gridPane1.getColumnConstraints().add(columnConstraints13);
        gridPane1.getColumnConstraints().add(columnConstraints14);
        gridPane1.getColumnConstraints().add(columnConstraints15);
        gridPane1.getRowConstraints().add(rowConstraints6);
        gridPane1.getChildren().add(button8);
        gridPane1.getChildren().add(text10);
        gridPane1.getChildren().add(text11);
        vBox1.getChildren().add(gridPane1);
        tableView.getColumns().add(tableColumn);
        tableView.getColumns().add(tableColumn0);
        vBox1.getChildren().add(tableView);
        anchorPane1.getChildren().add(vBox1);
        vBox.getChildren().add(anchorPane1);
        gridPane2.getChildren().add(text12);
        gridPane2.getChildren().add(button9);
        gridPane2.getChildren().add(imageView);
        gridPane2.getColumnConstraints().add(columnConstraints16);
        gridPane2.getColumnConstraints().add(columnConstraints17);
        gridPane2.getColumnConstraints().add(columnConstraints18);
        gridPane2.getRowConstraints().add(rowConstraints7);
        vBox2.getChildren().add(gridPane2);
        gridPane3.getChildren().add(text13);
        gridPane3.getChildren().add(button10);
        gridPane3.getChildren().add(imageView0);
        gridPane3.getColumnConstraints().add(columnConstraints19);
        gridPane3.getColumnConstraints().add(columnConstraints110);
        gridPane3.getColumnConstraints().add(columnConstraints111);
        gridPane3.getRowConstraints().add(rowConstraints8);
        vBox2.getChildren().add(gridPane3);
        gridPane4.getChildren().add(text14);
        gridPane4.getChildren().add(button11);
        gridPane4.getChildren().add(imageView1);
        gridPane4.getColumnConstraints().add(columnConstraints112);
        gridPane4.getColumnConstraints().add(columnConstraints113);
        gridPane4.getColumnConstraints().add(columnConstraints114);
        gridPane4.getRowConstraints().add(rowConstraints9);
        vBox2.getChildren().add(gridPane4);
        anchorPane2.getChildren().add(vBox2);
        vBox.getChildren().add(anchorPane2);
        tabPane.getTabs().add(tab);
        getChildren().add(tabPane);

    }
}
