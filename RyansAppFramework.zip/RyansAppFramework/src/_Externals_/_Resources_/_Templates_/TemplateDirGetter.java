package _Externals_._Resources_._Templates_;//Created by Ryan on 4/24/17.
import java.io.File;
public class TemplateDirGetter
{
    public static void main(String[] args)
    {
    }
    public static String getDir()

    {return new File("").getParent();}

}
